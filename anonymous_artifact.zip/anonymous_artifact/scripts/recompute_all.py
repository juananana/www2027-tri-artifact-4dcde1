"""Run every supported offline check from the artifact root."""

from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]


def run(script):
    subprocess.run([sys.executable, "-B", str(ROOT / "src" / script), str(ROOT)], check=True)


run("verify_artifact.py")
try:
    import numpy  # noqa: F401
except ImportError:
    print("NumPy is not installed; count/state verification passed, fixed-seed interval recomputation skipped.")
else:
    run("recompute_interleaved_statistics.py")
