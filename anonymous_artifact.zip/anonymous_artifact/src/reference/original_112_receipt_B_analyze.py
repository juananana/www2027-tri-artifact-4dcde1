"""Predeclared complete B audit and world-paired A/B statistics; no model calls."""
from pathlib import Path
from collections import Counter,defaultdict
import csv,hashlib,importlib.util,json
import numpy as np
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[3];A=HERE.parent/'wording_scale_20261025';WORK=ROOT/'www2027/analysis/final_validity_20261025'
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def read(p):return json.loads(p.read_text())
def save(name,x):
 p=HERE/name;raw=json.dumps(x,indent=2)+'\n'
 if p.exists():assert p.read_text()==raw,'refuse changed completed analysis'
 else:p.write_text(raw)
def canonical_joint(ledger):
 pairs=defaultdict(dict);joint=defaultdict(lambda:dict(actions=Counter(),proposals=Counter()))
 for r in ledger:pairs[r['model'],r['changed'],r['clarity'],r['world']][r['mode']]=r
 for (m,changed,form,w),d in pairs.items():
  assert len(d)==2;p,q=d['preserve'],d['reevaluate'];key='/'.join((m,'changed' if changed else 'unchanged',form))
  for field,kind in [('action_target','actions'),('proposed_target','proposals')]:
   a,b=p[field],q[field];old,new=p['old'],p['new']
   if a is None or b is None:label='both_missing' if a is None and b is None else 'preserve_missing' if a is None else 'reevaluate_missing'
   elif not changed:label='both_correct_same_target' if a==b==old else 'other_complete_pair'
   else:label={(old,new):'both_correct',(old,old):'earlier_on_both',(new,new):'updated_on_both',(new,old):'reversed'}.get((a,b),'other_complete_pair')
   joint[key][kind][label]+=1
 for key,j in joint.items():
  cats=['both_correct','earlier_on_both','updated_on_both','reversed','other_complete_pair'] if '/changed/' in key else ['both_correct_same_target','other_complete_pair']
  for counts in j.values():
   for k in cats+['preserve_missing','reevaluate_missing','both_missing']:counts.setdefault(k,0)
   assert sum(counts.values())==(112 if '/changed/' in key else 28)
 return dict(joint)
def main():
 for name in ['FREEZE.json','RECOVERY_FREEZE.json','PILOT_GATE_FREEZE.json','ANALYSIS_FREEZE.json']:
  for rel,h in read(HERE/name)['sha256'].items():assert hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==h,rel
 cases=read(A/'CASES.json');worlds={w['cluster_id']:w for w in read(A/'CLUSTERS.json')}
 missing=[c['id'] for c in cases if not (HERE/'runs'/c['model']/'primary'/c['id']/'RESULT.json').exists()]
 assert not missing,f'{len(missing)} unattempted formal rows; no complete comparison permitted'
 audit=load('independent_rq3',WORK/'audit_rq3.py');audit.RUN=HERE
 stream=load('independent_stream',A/'verify_retained_streams.py');stream.HERE=HERE
 ledger=[];hashes={};metrics=['assigned','list_reached','binding_or_defer_reached','initial_correct','sync_reached','post_refresh_response','post_refresh_ID_proposal','post_refresh_correct_proposal','post_refresh_record_choice_proposal','post_refresh_record_admitted','action_tool_proposed','action_invoked','receipt_ok','state_change_verified','correct_action','wrong_write','no_action','connection_failure','format_failure','tool_call_failure','early_termination','initialization_failure','captured_state_known','strict_success']
 for case in cases:
  w=worlds[case['fixture_id']];f=HERE/'runs'/case['model']/'primary'/case['id'];r=read(f/'RESULT.json')
  if not (f/'native_ids.initial.json').exists():
   assert r['error']=='FileNotFoundError' and r['trace']==[] and r['final'] is None and r['action_accepted'] is False
   assert not list(f.glob('*.request.json')) and not list(f.glob('action*'))
   row={k:0 for k in metrics};row.update(session=case['id'],model=case['model'],world=w['base_id'],family=w['selector_family'],changed=w['winner_change'],clarity=case['clarity'],mode=case['mode'],assigned=1,no_action=1,early_termination=1,initialization_failure=1,terminal='initialization_failure',terminal_step=0,final_tool=None,proposed_target=None,action_target=None,gold=w['gold'][case['mode']],old=w['old_target_id'],new=w['new_target_id'],changed_entities=None,raw_steps=[],requested_steps=[],source=str(f.relative_to(ROOT)))
  else:
   row=audit.audit(case,w);row.update(initialization_failure=0,captured_state_known=1,strict_success=int(r['strict_success']))
   for event in r['trace']:
    if event['tool']=='record_choice':assert event['receipt']=={'recorded':event['arguments'],'execution_note':'Decision recorded; no entity has been modified. After synchronization, call perform_action to carry out the requested modification.'}
  ledger.append(row)
  for p in f.iterdir():
   if p.is_file():hashes[str(p.relative_to(ROOT))]=hashlib.sha256(p.read_bytes()).hexdigest()
 groups=defaultdict(Counter);terminals=defaultdict(Counter)
 for r in ledger:
  key='/'.join((r['model'],'changed' if r['changed'] else 'unchanged',r['clarity'],r['mode']));groups[key].update({k:r[k] for k in metrics});terminals[key][str(r['terminal_step'])+'/'+r['terminal']+'/'+str(r['final_tool'])]+=1
 for g in groups.values():
  assert g['assigned']==g['correct_action']+g['wrong_write']+g['no_action']
  g['action_conditional_wrong_write_rate']=g['wrong_write']/g['action_invoked'] if g['action_invoked'] else None
 assert len(ledger)==1120 and sum(r['initialization_failure'] for r in ledger)==2
 stream_results=[stream.verify_request(p) for p in sorted((HERE/'runs').rglob('*.request.json'))]
 # Raw audit of every formal B row above plus independent A ledger. All comparisons predeclared.
 areport=read(WORK/'RQ3_AUDIT.json');aledger=areport['ledger'];byarm={'A':{r['session']:r for r in aledger},'B':{r['session']:r for r in ledger}}
 contrasts={}
 for m in ['qwen','glm']:
  keys=sorted({r['world'] for r in ledger if r['model']==m and r['changed']});assert len(keys)==112
  descriptors=[(form,mode,end) for form in ['short','explicit'] for mode in ['preserve','reevaluate'] for end in ['correct_action','wrong_write','no_action']]+[(form,'pair','both_actions') for form in ['short','explicit']]
  deltas=[];families=[]
  for world in keys:
   values=[];d={arm:{(r['clarity'],r['mode']):r for r in records.values() if r['model']==m and r['world']==world and r['changed']} for arm,records in byarm.items()}
   assert all(len(x)==4 for x in d.values());families.append(d['B']['short','preserve']['family'])
   for form,mode,end in descriptors:
    if mode=='pair':value=lambda arm:int(all(d[arm][form,x]['correct_action'] for x in ['preserve','reevaluate']))
    else:value=lambda arm:d[arm][form,mode][end]
    values.append(value('B')-value('A'))
   deltas.append(values)
  arr=np.array(deltas);fam=sorted(set(families));assert len(fam)==7;arrays={f:arr[np.array(families)==f] for f in fam};rng=np.random.default_rng(20261025);boot=[]
  for _ in range(10000):boot.append(np.concatenate([arrays[f][rng.integers(16,size=16)] for f in rng.choice(fam,7,replace=True)]).mean(axis=0)*100)
  ci=np.quantile(np.array(boot),[.025,.975],axis=0)
  for i,desc in enumerate(descriptors):
   k='/'.join((m,*desc));leave=[arr[np.array(families)!=f,i].mean()*100 for f in fam]
   contrasts[k]=dict(B_minus_A_points=float(arr[:,i].mean()*100),family_world_bootstrap95=[float(ci[0,i]),float(ci[1,i])],world_gains=int((arr[:,i]>0).sum()),world_losses=int((arr[:,i]<0).sum()),family_differences={f:float(arrays[f][:,i].mean()*100) for f in fam},leave_one_family_out_range=[float(min(leave)),float(max(leave))])
 joint=canonical_joint(ledger)
 costs={};prices={'qwen':(1.2,7.2),'glm':(8,28)}
 for m,(pin,pout) in prices.items():
  usage=Counter();req=list((HERE/'runs'/m).rglob('*.request.json'));response=list((HERE/'runs'/m).rglob('*.response.json'))
  for p in response:usage.update(read(p)['usage'])
  usage_cost=(usage['prompt_tokens']*pin+usage['completion_tokens']*pout)/1e6
  costs[m]=dict(requests=len(req),responses=len(response),usage_reference_cny=usage_cost,missing_response_reserved_cny=(len(req)-len(response))*(24000*pin+4096*pout)/1e6)
 report=dict(status='COMPLETE_AUDITED',assigned=1120,attempted=1120,model_calls_from_analysis=0,groups=dict(groups),terminal_counts=dict(terminals),joint=joint,contrasts=contrasts,bootstrap_draws=10000,bootstrap_seed=20261025,analysis_unit='base world; all correlated conditions grouped; seven authored families',comparison_scope='receipt-only requested protocol; sequential hosted A/B not pinned-backend causal isolation',costs=costs,actual_billing='unknown',stream_requests_checked=len(stream_results),stream_failures=sum(x['outcome']=='retained_failure' for x in stream_results),ledger=ledger,input_sha256=hashes)
 save('RESULT_AUDIT.json',report)
 with (HERE/'SESSION_LEDGER.csv').open('w') as f:
  writer=csv.DictWriter(f,fieldnames=ledger[0].keys());writer.writeheader();writer.writerows(ledger)
 lines=['# Receipt clarification: complete A/B evidence audit','','All 1120 B assignments retained, including two initialization failures before any model request. Pilot and health are excluded from scientific endpoints. Original A remains unchanged. Correct/wrong/no-action partitions assignments. Phase counts overlap. The two initialization rows have no captured state; absence of an action is verified from no requests/trace/action attempt, not from an invented state snapshot.','', '| Model/update/text/mode | N | B correct/wrong/none | A correct/wrong/none | Correct ID | Invoked | API failure | Init failure |','|---|---:|---|---|---:|---:|---:|---:|']
 for k,g in sorted(groups.items()):
  a=areport['groups'][k];fields=['correct_action','wrong_write','no_action'];lines.append('| '+k+f" | {g['assigned']} | "+'/'.join(str(g[x]) for x in fields)+' | '+'/'.join(str(a[x]) for x in fields)+f" | {g['post_refresh_correct_proposal']} | {g['action_invoked']} | {g['connection_failure']} | {g['initialization_failure']} |")
 lines+=['','## Changed-world B minus A contrasts','', 'Descriptive 95% family/world bootstrap intervals, 10000 draws; no multiplicity-adjusted confirmatory claims.']
 for k,c in contrasts.items():lines.append(f"- {k}: {c['B_minus_A_points']:.2f} points; 95% [{c['family_world_bootstrap95'][0]:.2f}, {c['family_world_bootstrap95'][1]:.2f}]; gains/losses {c['world_gains']}/{c['world_losses']}.")
 lines+=['','## Joint actions and proposals','']
 for k,j in sorted(joint.items()):lines+=['- '+k+': '+json.dumps(j,sort_keys=True)]
 lines+=['','## Cost and limitations','',json.dumps(costs,indent=2),'','Actual billing is unknown. All response streams or failures checked; exact source hashes are recorded. No post-hoc arm exclusion or rerun. A/B hosted timing/backend drift cannot be excluded; this contrast tests receipt sensitivity under the same requested settings and fixed four-turn protocol, not open-ended autonomy or an extra action turn.']
 (HERE/'REPORT.md').write_text('\n'.join(lines)+'\n')
 print(json.dumps({k:v for k,v in report.items() if k not in ['ledger','input_sha256','contrasts','terminal_counts']},indent=2))
if __name__=='__main__':main()
