"""Independent standard-library replay of raw E25 evidence; no API/native imports."""
import argparse
import ast
from copy import deepcopy
from datetime import date,timedelta
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[3]
def read(path):return json.loads(path.read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def canonical(state):return sorted(state,key=lambda r:r['id'])
def public(state,ids):
 return [{'persistent_id':str(ids[r['id']]),**{k:v for k,v in r.items() if k!='id'}} for r in sorted(state,key=lambda r:ids[r['id']])]
def parse(raw,stage):
 o=json.loads(raw)
 if not isinstance(o,dict) or set(o)!={'decision','target_id'}:raise ValueError('invalid fields')
 if o['decision'] not in ({'bind','defer','clarify'} if stage=='initial' else {'act','clarify'}):raise ValueError('invalid stage')
 if o['decision'] in {'bind','act'}:
  if not isinstance(o['target_id'],str) or not o['target_id'].strip():raise ValueError('invalid ID')
  o['target_id']=o['target_id'].strip()
 elif o['target_id'] is not None:raise ValueError('unexpected ID')
 return o
def parse_or_none(raw,stage):
 try:return parse(raw,stage)
 except (ValueError,TypeError,KeyError):return None

def winner(row,state):
 def value(r):
  v=r[row['selector_field']]
  return len(v) if row['selector_value_kind']=='length' else str(v).casefold() if row['selector_value_kind']=='text' else v
 good=[r for r in state if (r.get('active',True) if row['app']=='calendar' else not r.get('done',False) if row['app']=='todoist' else not r.get('deleted',False) and 'tri-w1' in r['tags'])]
 best=(min if row['selector_direction']=='min' else max)(value(r) for r in good)
 found=[r['id'] for r in good if value(r)==best]
 assert len(found)==1
 return found[0]
def after(row,target):
 state=deepcopy(row['s1']);ent=next(r for r in state if r['id']==target)
 if row['action']=='delete':state.remove(ent)
 elif row['action']=='postpone_one_day':ent['due_date']=(date.fromisoformat(ent['due_date'])+timedelta(days=1)).isoformat()
 elif row['action']=='mark_complete':ent['done']=True
 elif row['action']=='append_reviewed':ent['content']+='\nreviewed'
 elif row['action']=='prepend_reviewed':ent['content']='reviewed\n'+ent['content']
 else:raise ValueError('unknown action')
 return canonical(state)

def main(model,phase):
 for rel,digest in read(HERE/'INPUT_MANIFEST.json').items():assert sha(ROOT/rel)==digest,rel
 source=ROOT/'www2027/sandbox_research/controlled_extension/e23_minimal_execution_001/experiment.py'
 tree=ast.parse(source.read_text())
 system=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SYSTEM' for t in n.targets))
 worlds={r['cluster_id']:r for r in (json.loads(s) for s in (HERE/'CLUSTERS.jsonl').read_text().splitlines())}
 cases=[c for c in read(HERE/'CASES.json') if phase=='complete' or c['smoke']]
 run=HERE/'runs'/model
 audited=read(run/('FINAL_AUDIT.json' if phase=='complete' else 'SMOKE_AUDIT.json'))
 assert audited['technical_gate_pass']
 scores={s['session_id']:s for s in audited['scores']}
 config=read(HERE/'configs'/model/'RUN_CONFIG.json')
 provider_ids=[];reference=0;recomputed=[]
 for case in cases:
  job=run/'jobs'/case['session_id'];row=worlds[case['cluster_id']];result=read(job/'RESULT.json')
  assert result['case']==case
  old=winner(row,row['s0']);new=winner(row,row['s1'])
  assert row['gold']=={'preserve':old,'reevaluate':new}
  ids0=read(job/'native_ids.initial.json');req0=read(job/'call_00.request.json')['body']
  raw0=read(job/'call_00.raw.json')['body']['choices'][0]['message'].get('content') or ''
  if case['kind']=='selector_probe':
   ids=read(job/'native_ids.after_update.json');state=public(row['s1'],ids)
   assert json.loads(req0['messages'][1]['content'])=={'selection_rule':row['selector_text'],'entities':state}
   o=parse_or_none(raw0,'final');selected={str(v):k for k,v in ids.items()}.get(o['target_id']) if o else None
   assert selected==result['selected_logical_id']
   assert not (job/'action.receipt.json').exists()
   assert scores[case['session_id']]['correct']==(selected==new)
  else:
   initial=public(row['s0'],ids0)
   assert req0['messages']==[{'role':'system','content':system},{'role':'user','content':case['instruction']},{'role':'user','content':'SERVICE_OBSERVATION '+json.dumps({'stage':'initial_observation','entities':initial},sort_keys=True)}]
   first=parse_or_none(raw0,'initial');assert first==result['first']
   bound={str(v):k for k,v in ids0.items()}.get(first['target_id']) if first else None
   assert bound==result['bound_logical_id']
   acted=False;selected=None
   if result['refreshed_state'] is not None:
    ids=read(job/'native_ids.after_update.json');assert all(ids[k]==v for k,v in ids0.items())
    req1=read(job/'call_01.request.json')['body']
    assert req1['messages']==req0['messages']+[{'role':'assistant','content':json.dumps(first,sort_keys=True)},{'role':'user','content':'SERVICE_OBSERVATION '+json.dumps({'stage':'refreshed_observation','entities':public(row['s1'],ids)},sort_keys=True)}]
    raw1=read(job/'call_01.raw.json')['body']['choices'][0]['message'].get('content') or ''
    final=parse_or_none(raw1,'final');assert final==result['final_decision']
    selected={str(v):k for k,v in ids.items()}.get(final['target_id']) if final else None
    assert selected==result['action_logical_id']
    acted=(job/'action.receipt.json').exists()
    if acted:
     assert final['decision']=='act' and selected is not None
     receipt=read(job/'action.receipt.json');assert receipt['logical_id']==selected
     assert canonical(read(job/'final.logical.json'))==after(row,selected)
   else:assert not (job/'call_01.request.json').exists()
   initial_ok=bool(first and ((first['decision']=='bind' and bound==old) if case['mode']=='preserve' else first['decision']=='defer'))
   correct=acted and selected==row['gold'][case['mode']]
   exact=acted and canonical(read(job/'final.logical.json'))==after(row,row['gold'][case['mode']])
   eligible=bool(case['mode']=='preserve' and initial_ok and result['refreshed_state'] is not None and row['winner_change'])
   computed=dict(initial_compliance=initial_ok,correct_action=bool(correct),exact_final=bool(exact),strict=bool(initial_ok and correct and exact),wrong_write=bool(acted and not correct),no_action=not acted,conditional_preserve_eligible=eligible,post_binding_substitution=bool(eligible and acted and selected!=old))
   assert all(scores[case['session_id']][k]==v for k,v in computed.items()),case['session_id']
   recomputed.append(dict(session_id=case['session_id'],**computed))
  assert canonical(read(job/'final.logical.json'))==canonical(result['final_state'])
  for path in job.glob('call_*.request.json'):
   stem=path.name.removesuffix('.request.json');req=read(path)['body'];resp=read(job/(stem+'.response.json'));raw=read(job/(stem+'.raw.json'))
   assert resp['http_status']==200 and resp['body']==raw['body']
   for k in ('model','temperature','top_p','max_completion_tokens','enable_thinking'):assert req[k]==config[k]
   usage=raw['body']['usage'];reference+=(usage['prompt_tokens']*config['input_price_cny_per_m']+usage['completion_tokens']*config['output_price_cny_per_m'])/1e6
   provider_ids.append(raw['body']['id'])
 for pair in audited['pairs']:
  sides=[scores[c['session_id']] for c in cases if c['cluster_id']==pair['cluster_id'] and c['kind']=='execution']
  assert len(sides)==2
  assert pair['both_action_correct']==all(s['correct_action'] for s in sides)
  assert pair['both_strict']==all(s['strict'] for s in sides)
 assert len(set(provider_ids))==len(provider_ids)==audited['requests']
 assert abs(reference-audited['reference_cost_cny'])<1e-8
 out=dict(status='PASS',model=model,phase=phase,assigned=len(cases),sessions_recomputed=len(recomputed),requests=len(provider_ids),reference_cost_cny=round(reference,9),actual_billing='unknown',independent_replay='standard-library only; no native/runtime/client/scorer imports; no API',script_sha256=sha(Path(__file__)),source_audit_sha256=sha(run/('FINAL_AUDIT.json' if phase=='complete' else 'SMOKE_AUDIT.json')))
 path=run/('OFFLINE_REPRODUCIBILITY_AUDIT.json' if phase=='complete' else 'SMOKE_OFFLINE_REPRODUCIBILITY_AUDIT.json')
 content=json.dumps(out,indent=2,sort_keys=True)+'\n'
 if path.exists():assert path.read_text()==content
 else:path.write_text(content)
 print(json.dumps(out))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('phase',choices=['smoke','complete']);p.add_argument('--model',choices=['qwen','glm'],required=True);a=p.parse_args();main(a.model,a.phase)
