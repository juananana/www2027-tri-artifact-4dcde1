"""Post-hoc zero-API sensitivity checks; never modifies source evidence."""
from pathlib import Path
from collections import Counter
from itertools import product
import json, hashlib
HERE = Path(__file__).resolve().parent
OUT = HERE / "combined_analysis"
def read(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
audit_path = OUT / "PRIMARY_AUDIT.json"
stat_path = OUT / "STATISTICAL_RESULT.json"
a = read(audit_path); stats = read(stat_path)
rows = a["ledger"]
assert len(rows) == len({r["session"] for r in rows}) == 1680
by = {(r["arm"], r["clarity"], r["world"], r["mode"]): r for r in rows if r["changed"]}
worlds = sorted({r["world"] for r in rows if r["changed"]})
fam = {r["world"]: r["family"] for r in rows if r["changed"]}
families = sorted(set(fam.values()))
assert len(worlds) == 112 and len(families) == 7

def pair(arm, form, w):
    return [by[arm, form, w, mode] for mode in ("preserve", "reevaluate")]
def bounds(arm, form, w):
    rs = pair(arm, form, w)
    lo = int(all(r["correct"] for r in rs))
    hi = int(all(r["correct"] or r["unavailable"] for r in rs))
    return lo, hi
contrasts = {}
for x, y in (("B", "A"), ("C", "B")):
    for form in ("short", "explicit"):
        key = f"{x}-{y}/{form}"
        lower = sum(bounds(x,form,w)[0]-bounds(y,form,w)[1] for w in worlds)
        upper = sum(bounds(x,form,w)[1]-bounds(y,form,w)[0] for w in worlds)
        # Independent exhaustive enumeration of every unknown within each matched world.
        enumerated = []
        for w in worlds:
            rr = pair(x, form, w) + pair(y, form, w)
            values = [([0,1] if r["unavailable"] else [r["correct"]]) for r in rr]
            delta = [v[0]*v[1]-v[2]*v[3] for v in product(*values)]
            enumerated.append((min(delta),max(delta)))
        assert lower == sum(v[0] for v in enumerated)
        assert upper == sum(v[1] for v in enumerated)
        complete = [w for w in worlds if not any(r["unavailable"] for arm in (x,y) for r in pair(arm,form,w))]
        observed = lambda arm,w: bounds(arm,form,w)[0]
        per_family = {f: sum(observed(x,w)-observed(y,w) for w in worlds if fam[w]==f) for f in families}
        loo = [sum(observed(x,w)-observed(y,w) for w in worlds if fam[w]!=f)/96*100 for f in families]
        old = stats["contrasts"][f"{key}/pair/both_actions"]
        assert all(abs(u-v)<1e-10 for u,v in zip(loo,old["leave_one_family_out"]))
        contrasts[key] = dict(transport_bounds_counts=[lower,upper], transport_bounds_pp=[lower/112*100,upper/112*100],
            matched_no_transport_worlds=len(complete), matched_no_transport_success={arm:sum(observed(arm,w) for w in complete) for arm in (x,y)},
            family_delta_out_of_16=per_family, leave_one_family_out_pp=[min(loo),max(loo)])
# Trace-stage partition for all arms and conditions; raw files read without executing model/native code.
stages = {}; traces = {}; source_hash = {}
for r in rows:
    folder = Path(a["source_locations"][r["session"]]); p = folder/"RESULT.json"; z = read(p)
    source_hash[str(p)] = sha(p)
    traces[r["session"]] = z
    assert bool(z["correct_action"]) == bool(r["correct"])
    assert bool(z["initial_correct"]) == bool(r["initial"])
    assert bool(z["synchronized"]) == any(t["tool"]=="synchronize" for t in z["trace"])
    if r["correct"]: cat="correct_action"
    elif r["wrong"]: cat="wrong_write"
    elif r["unavailable"]: cat="transport_unavailable"
    else:
        raw_files=sorted(folder.glob("call_*.raw.json"),key=lambda p:int(p.name.split("_")[1].split(".")[0]))
        assert raw_files
        raw = raw_files[-1]; source_hash[str(raw)] = sha(raw)
        try:
            cmd=json.loads(read(raw)["choices"][0]["message"]["content"])
            valid=isinstance(cmd,dict)
        except (ValueError,TypeError): valid=False
        cat=("other_protocol_failure" if valid else "non_json_after_refresh" if z["synchronized"] else "non_json_before_refresh")
        if not valid and not z["trace"]: cat="non_json_first_response"
    key="/".join([r["arm"],r["clarity"],"changed" if r["changed"] else "unchanged",r["mode"]])
    stages.setdefault(key,Counter())[cat]+=1
assert sum(sum(c.values()) for c in stages.values())==1680
for key, counts in stages.items():
    arm,form,change,mode=key.split("/")
    rr=[r for r in rows if r["arm"]==arm and r["clarity"]==form and r["changed"]==(change=="changed") and r["mode"]==mode]
    assert counts["correct_action"]==sum(r["correct"] for r in rr)
    assert counts["wrong_write"]==sum(r["wrong"] for r in rr)
    assert sum(v for k,v in counts.items() if k not in ("correct_action","wrong_write"))==sum(r["no_action"] for r in rr)
gaps = {}; preserve = {}
for form in ("short","explicit"):
    counts=Counter()
    for w in worlds:
        rr=pair("C",form,w)
        if all(r["correct"] for r in rr) and not all(r["strict"] for r in rr):
            zz=[traces[r["session"]] for r in rr]
            missing=any(z["prefix"] is None for z in zz)
            incorrect=any(z["prefix"] is not None and not z["initial_correct"] for z in zz)
            other=any(z["error"] is not None for z in zz)
            assert missing or incorrect or other
            counts[f"missing={missing};incorrect_observed={incorrect};other_error={other}"]+=1
    gaps[form]=dict(counts)
    for arm in ("A","B","C"):
        rr=[r for r in rows if r["changed"] and r["arm"]==arm and r["clarity"]==form and r["mode"]=="preserve"]
        eligible=[r for r in rr if r["initial"] and traces[r["session"]]["synchronized"]]
        preserve[f"{arm}/{form}"]=dict(correct_initial_and_refresh=len(eligible),wrong_writes=sum(r["wrong"] for r in eligible),all_wrong_writes=sum(r["wrong"] for r in rr))
result=dict(status="PASS",analysis_status="post_hoc",assigned=1680,contrasts=contrasts,stages={k:dict(v) for k,v in stages.items()},C_correct_but_not_strict_pair_reasons=gaps,preserve_localization=preserve,
    source_sha256={str(audit_path):sha(audit_path),str(stat_path):sha(stat_path)},trace_files_verified=len(source_hash),trace_manifest_sha256=hashlib.sha256(json.dumps(source_hash,sort_keys=True).encode()).hexdigest())
(OUT/"COMPLETENESS_RESULT.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))

# Manuscript fragments remain derived from the retained audit.
ROOT=HERE.parents[3]
GENERATED=ROOT/"TRI_final_narrative_revision_20261013/paper/generated"
ba=contrasts["B-A/explicit"]; cb=contrasts["C-B/explicit"]; cs=contrasts["C-B/short"]
def span(vals): return "["+",".join(f"{v:.1f}" for v in vals)+"]"
robust = (
    "\\paragraph{Transport and family sensitivity.}\n"
    "A post-hoc bound varies only transport-unavailable session outcomes, keeping every observed format and semantic outcome fixed. "
    "A pair can become correct only when both constituent sessions are observed correct or unavailable. "
    f"Across all such assignments, the explicit B--A paired-action difference lies in {span(ba['transport_bounds_pp'])} percentage points; "
    f"C--B lies in {span(cb['transport_bounds_pp'])} for explicit instructions and {span(cs['transport_bounds_pp'])} for short instructions. "
    "These deterministic bounds address missing transport outcomes, not sampling uncertainty, hosted-model drift or effects of recovery amendments; they do not replace the primary intervals. "
    f"B exceeds A in all seven explicit families. Removing one family at a time leaves B--A between {ba['leave_one_family_out_pp'][0]:.1f} and {ba['leave_one_family_out_pp'][1]:.1f} points; "
    f"C--B remains between {cb['leave_one_family_out_pp'][0]:.1f} and {cb['leave_one_family_out_pp'][1]:.1f}. "
    "C trails B in six explicit families and ties in one. These checks do not establish generalization beyond the seven authored families.\n\n"
    "\\paragraph{Post-hoc failure localization.}\n"
    f"All {stages['C/explicit/changed/preserve']['non_json_first_response']} non-transport no-action failures in explicit C Preserve occur on the first response, before listing or refresh: the output is not a JSON command. "
    "They are format failures, not evidence of post-binding target substitution. "
    f"For short C Preserve, {stages['C/short/changed/preserve']['non_json_first_response']} no-action failures have the same form and {stages['C/short/changed/preserve']['transport_unavailable']} are transport losses. "
    "The primary scores retain these failures; no permissive reparsing or rerun is used. "
    "Every correct-action pair that fails the strict criterion in C lacks a required initial record: "
    f"{sum(gaps['explicit'].values())} explicit pairs and {sum(gaps['short'].values())} short pairs. None contains an observed incorrect initial record. "
    "Because C permits omitting this record, that gap describes missing process evidence under the stricter audit, not demonstrated violation of user-specified timing. "
    f"Among short Preserve sessions with a correct initial binding and completed refresh, A has {preserve['A/short']['wrong_writes']}/{preserve['A/short']['correct_initial_and_refresh']} wrong writes and B has {preserve['B/short']['wrong_writes']}/{preserve['B/short']['correct_initial_and_refresh']}; "
    f"C has only {preserve['C/short']['correct_initial_and_refresh']} observable eligible session, so its {preserve['C/short']['all_wrong_writes']} wrong writes cannot all be attributed to post-binding substitution. "
    "Under explicit instructions, no arm has a wrong write after a correct observable initial Preserve binding and refresh.\n"
)
(GENERATED/"interleaved_robustness.tex").write_text(robust)
