from __future__ import annotations

from contextlib import contextmanager
from datetime import date, timedelta
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
from typing import Any, Iterator
import urllib.parse
import urllib.request


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
W0 = HERE.parent / "web_native_w0_001"
OPENAPPS_DEFAULT = ROOT / "www2027/sandbox_research/OpenApps_source"
CALENDAR_SOURCE_SHA256 = "74d098bfa32f76d4639f802ec56230aff9a78ea4ce0ada40657710852a55b2e4"


def load_module(name: str, path: Path) -> Any:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.path.insert(0, str(path.parent))
    try:
        spec.loader.exec_module(module)
    finally:
        sys.path.pop(0)
    return module


APP_NATIVE = load_module("w1pilot_appnative", W0 / "native_appworld_check.py")
CAL_NATIVE = load_module("w1pilot_calnative", W0 / "native_calendar_check.py")


def atomic_json(path: Path, value: Any) -> None:
    content = json.dumps(value, indent=2, ensure_ascii=True, sort_keys=True) + "\n"
    if path.exists():
        if path.read_text(encoding="utf-8") != content:
            raise RuntimeError(f"refuse changed evidence: {path}")
    else:
        path.write_text(content, encoding="utf-8")


def public_state(logical: list[dict[str, Any]], ids: dict[str, int]) -> list[dict[str, Any]]:
    return [
        {"persistent_id": str(ids[entity["id"]]), **{k: v for k, v in entity.items() if k != "id"}}
        for entity in sorted(logical, key=lambda item: ids[item["id"]])
    ]


class AppWorldSession:
    def __init__(self, world: Any, row: dict[str, Any], ids: dict[str, int], evidence: Path):
        self.world = world
        self.row = row
        self.ids = ids
        self.evidence = evidence
        self.synced = False
        self.s0 = APP_NATIVE.snapshot(world, row, ids)
        self.s1: list[dict[str, Any]] | None = None
        self.final: list[dict[str, Any]] | None = None
        self.update_receipt: dict[str, Any] | None = None
        self.action_receipt: dict[str, Any] | None = None

    def list_entities(self) -> list[dict[str, Any]]:
        logical = APP_NATIVE.snapshot(self.world, self.row, self.ids)
        return public_state(logical, self.ids)

    def synchronize(self) -> dict[str, Any]:
        if self.synced:
            raise RuntimeError("synchronize may be called only once")
        self.update_receipt = APP_NATIVE.apply_native_update(self.world, self.row, self.ids)
        self.s1 = APP_NATIVE.snapshot(self.world, self.row, self.ids)
        if self.s1 != sorted(self.row["s1"], key=lambda entity: entity["id"]):
            raise RuntimeError("AppWorld S1 differs from frozen inventory")
        self.synced = True
        atomic_json(self.evidence / "native_ids.after_update.json", self.ids)
        atomic_json(self.evidence / "update.receipt.json", self.update_receipt)
        atomic_json(self.evidence / "s1.logical.json", self.s1)
        return {"status": "ok", "message": "Synchronization completed."}

    def perform_action(self, native_id: str) -> dict[str, Any]:
        reverse = {str(native): logical for logical, native in self.ids.items()}
        if native_id not in reverse:
            return {"status": "rejected", "error": "unknown persistent ID"}
        logical_id = reverse[native_id]
        self.action_receipt = APP_NATIVE.apply_native_action(self.world, self.row, logical_id, self.ids)
        atomic_json(self.evidence / "action.receipt.json", self.action_receipt)
        return {"status": "ok", "persistent_id": native_id}

    def close(self) -> None:
        self.final = APP_NATIVE.snapshot(self.world, self.row, self.ids)
        atomic_json(self.evidence / "final.logical.json", self.final)


@contextmanager
def appworld_session(row: dict[str, Any], job_id: str, evidence: Path) -> Iterator[AppWorldSession]:
    APP_NATIVE.prepare_overlay()
    from appworld import AppWorld

    experiment = "w1pilot_" + job_id.replace("-", "_")
    with AppWorld(task_id=APP_NATIVE.BASE_TASK_ID, experiment_name=experiment) as world:
        ids = APP_NATIVE.setup(world, row)
        session = AppWorldSession(world, row, ids, evidence)
        if session.s0 != sorted(row["s0"], key=lambda entity: entity["id"]):
            raise RuntimeError("AppWorld S0 differs from frozen inventory")
        atomic_json(evidence / "native_ids.initial.json", ids)
        atomic_json(evidence / "s0.logical.json", session.s0)
        try:
            yield session
        finally:
            session.close()


def free_port() -> int:
    with socket.socket() as handle:
        handle.bind(("127.0.0.1", 0))
        return int(handle.getsockname()[1])


class CalendarSession:
    def __init__(self, row: dict[str, Any], ids: dict[str, int], evidence: Path, base: str):
        self.row = row
        self.ids = ids
        self.evidence = evidence
        self.base = base
        self.synced = False
        initial_raw = CAL_NATIVE.raw_state(base)
        atomic_json(evidence / "s0.raw.json", initial_raw)
        self.s0 = CAL_NATIVE.normalize(initial_raw, ids)
        self.s1: list[dict[str, Any]] | None = None
        self.final: list[dict[str, Any]] | None = None
        self.update_receipt: dict[str, Any] | None = None
        self.action_receipt: dict[str, Any] | None = None

    def list_entities(self) -> list[dict[str, Any]]:
        return public_state(CAL_NATIVE.normalize(CAL_NATIVE.raw_state(self.base), self.ids), self.ids)

    def synchronize(self) -> dict[str, Any]:
        if self.synced:
            raise RuntimeError("synchronize may be called only once")
        update = self.row["update"]
        if update["kind"] != "insert":
            raise RuntimeError("Calendar pilot expects the frozen insertion transition")
        entity = update["entity"]
        status, final_url, body = CAL_NATIVE.call(
            self.base,
            "/calendar/create_event/save_text",
            "POST",
            {
                "title": entity["title"],
                "date": entity["date"],
                "description": f"W1 pilot update for {self.row['cluster_id']}",
                "location": entity["location"],
                "recurring": "none",
            },
        )
        raw = CAL_NATIVE.raw_state(self.base)
        new_ids = {event["id"] for event in raw} - set(self.ids.values())
        if len(new_ids) != 1:
            raise RuntimeError("Calendar synchronization did not create one persistent entity")
        self.ids[entity["id"]] = new_ids.pop()
        self.update_receipt = {
            "status": status,
            "final_url": final_url,
            "body_sha256": hashlib.sha256(body.encode()).hexdigest(),
            "logical_id": entity["id"],
            "native_id": self.ids[entity["id"]],
        }
        self.s1 = CAL_NATIVE.normalize(raw, self.ids)
        if self.s1 != sorted(self.row["s1"], key=lambda item: item["id"]):
            raise RuntimeError("Calendar S1 differs from frozen inventory")
        self.synced = True
        atomic_json(self.evidence / "native_ids.after_update.json", self.ids)
        atomic_json(self.evidence / "update.receipt.json", self.update_receipt)
        atomic_json(self.evidence / "s1.raw.json", raw)
        atomic_json(self.evidence / "s1.logical.json", self.s1)
        return {"status": "ok", "message": "Synchronization completed."}

    def perform_action(self, native_id: str) -> dict[str, Any]:
        reverse = {str(native): logical for logical, native in self.ids.items()}
        if native_id not in reverse:
            return {"status": "rejected", "error": "unknown persistent ID"}
        status, final_url, body = CAL_NATIVE.call(
            self.base, f"/calendar/event/{int(native_id)}/delete", "POST", {}
        )
        self.action_receipt = {
            "status": status,
            "final_url": final_url,
            "body_sha256": hashlib.sha256(body.encode()).hexdigest(),
            "logical_id": reverse[native_id],
            "native_id": int(native_id),
        }
        atomic_json(self.evidence / "action.receipt.json", self.action_receipt)
        return {"status": "ok", "persistent_id": native_id}

    def close(self) -> None:
        raw = CAL_NATIVE.raw_state(self.base)
        self.final = CAL_NATIVE.normalize(raw, self.ids)
        atomic_json(self.evidence / "final.raw.json", raw)
        atomic_json(self.evidence / "final.logical.json", self.final)


@contextmanager
def calendar_session(row: dict[str, Any], job_id: str, evidence: Path) -> Iterator[CalendarSession]:
    openapps = Path(os.environ.get("TRI_OPENAPPS_SOURCE", str(OPENAPPS_DEFAULT)))
    source_file = openapps / "src/open_apps/apps/calendar_app/main.py"
    if hashlib.sha256(source_file.read_bytes()).hexdigest() != CALENDAR_SOURCE_SHA256:
        raise RuntimeError("Calendar source hash differs from qualified W0 source")
    python = Path(os.environ.get("TRI_CALENDAR_PYTHON", "/tmp/tri-openapps-w1-venv/bin/python"))
    if not python.is_file():
        raise RuntimeError(f"Calendar runtime is absent: {python}")
    fixture, ids = CAL_NATIVE.fixture(row)
    fixture_path = evidence / "fixture.json"
    atomic_json(fixture_path, fixture)
    port = free_port()
    episode = "w1pilot_" + job_id.replace("-", "_")
    log_path = evidence / "calendar_server.log"
    environment = dict(os.environ)
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    with log_path.open("x", encoding="utf-8") as log:
        process = subprocess.Popen(
            [
                str(python),
                "-B",
                str(W0 / "calendar_server.py"),
                "--source-root",
                str(openapps),
                "--runtime-root",
                str(HERE / "runtime_calendar"),
                "--episode",
                episode,
                "--fixture",
                str(fixture_path),
                "--port",
                str(port),
            ],
            stdout=log,
            stderr=subprocess.STDOUT,
            env=environment,
        )
        base = f"http://127.0.0.1:{port}"
        try:
            for _ in range(120):
                if process.poll() is not None:
                    raise RuntimeError("Calendar server exited during startup")
                try:
                    CAL_NATIVE.raw_state(base)
                    break
                except OSError:
                    time.sleep(0.25)
            else:
                raise RuntimeError("Calendar server did not become ready")
            session = CalendarSession(row, ids, evidence, base)
            if session.s0 != sorted(row["s0"], key=lambda item: item["id"]):
                raise RuntimeError("Calendar S0 differs from frozen inventory")
            atomic_json(evidence / "native_ids.initial.json", ids)
            try:
                yield session
            finally:
                session.close()
        finally:
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=10)


def native_session(row: dict[str, Any], job_id: str, evidence: Path) -> Any:
    return calendar_session(row, job_id, evidence) if row["app"] == "calendar" else appworld_session(row, job_id, evidence)

