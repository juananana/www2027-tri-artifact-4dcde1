"""Fixed supplemental controls and matched-update analysis, frozen before paid requests."""
import argparse
from collections import Counter
from pathlib import Path
import experiment as x

HERE=Path(__file__).resolve().parent

def calibration(worlds):
    policies={}
    for policy in ('always_old','always_current','timing_aware_oracle'):
        table={}
        for changed in (True,False):
            selected=[r for r in worlds if r['winner_change']==changed]
            counts=Counter()
            for row in selected:
                success=[]
                for mode in ('preserve','reevaluate'):
                    initial=x.BUILD.winner(row,row['s0']);current=x.BUILD.winner(row,row['s1'])
                    target=initial if policy=='always_old' else current
                    if policy=='timing_aware_oracle':target=initial if mode=='preserve' else current
                    correct=target==row['gold'][mode]
                    counts[mode]+=correct;success.append(correct)
                counts['both']+=all(success)
            table['changed' if changed else 'unchanged']=dict(n=len(selected),**counts)
        policies[policy]=table
    return policies

def preflight():
    x.select('qwen');worlds=x.check()
    result=calibration(worlds)
    assert result['always_old']['changed']==dict(n=504,preserve=504,reevaluate=0,both=0)
    assert result['always_current']['changed']==dict(n=504,preserve=0,reevaluate=504,both=0)
    for p in result.values():assert p['unchanged']['both']==36
    assert result['timing_aware_oracle']['changed']['both']==504
    x.write(HERE/'OFFLINE_CONTROLS.json',dict(status='PASS',model_calls=0,policies=result,
        evidence='computed target predictions from frozen states, not learned baselines or additional native executions',
        inventory_sha256=x.sha(HERE/'CLUSTERS.jsonl'),script_sha256=x.sha(Path(__file__))))
    x.write(HERE/'ANALYSIS_FREEZE.json',dict(status='FROZEN_BEFORE_PAID_REQUESTS',
        model_requests_at_freeze=len(list(HERE.glob('runs/*/jobs/*/call_*.request.json'))),
        script_sha256=x.sha(Path(__file__)),input_manifest_sha256=x.sha(HERE/'INPUT_MANIFEST.json'),
        planned_comparison='within the same 36 preset worlds: unchanged versus changed; no comparison of unmatched 504/36 denominators',
        planned_metrics=['both_action_correct','both_strict','wrong_write','initial_compliance','terminal categories']))
    assert not list(HERE.glob('runs/*/jobs/*/call_*.request.json'))
    print('{"status":"PASS","offline_policies":3,"model_calls":0}')

def post():
    freeze=x.read(HERE/'ANALYSIS_FREEZE.json')
    assert freeze['script_sha256']==x.sha(Path(__file__)) and freeze['model_requests_at_freeze']==0
    worlds={r['cluster_id']:r for r in x.rows(HERE/'CLUSTERS.jsonl')}
    output={}
    for model in x.MODELS:
        a=x.read(HERE/'runs'/model/'FINAL_AUDIT.json');assert a['technical_gate_pass']
        pairs={p['cluster_id']:p for p in a['pairs']}
        update=[]
        for stable in (r for r in worlds.values() if not r['winner_change']):
            changed=next(r for r in worlds.values() if r['base_id']==stable['base_id'] and r['winner_change'])
            update.append(dict(base_id=stable['base_id'],family=stable['selector_family'],
                changed_pair=pairs[changed['cluster_id']]['both_action_correct'],
                unchanged_pair=pairs[stable['cluster_id']]['both_action_correct']))
        execs=[s for s in a['scores'] if s['kind']=='execution']
        changed=[s for s in execs if s['changed']]
        initial_wrong=[s for s in changed if not s['initial_compliance']]
        output[model]=dict(matched_update_worlds=36,matched_update_rows=update,
            changed_correct=sum(r['changed_pair'] for r in update),unchanged_correct=sum(r['unchanged_pair'] for r in update),
            unchanged_only=sum(r['unchanged_pair'] and not r['changed_pair'] for r in update),
            changed_only=sum(r['changed_pair'] and not r['unchanged_pair'] for r in update),
            terminal_counts=dict(Counter(s['terminal'] for s in execs)),
            changed_initial_noncompliance=len(initial_wrong),
            changed_initial_noncompliant_but_action_correct=sum(s['correct_action'] for s in initial_wrong),
            changed_actual_wrong_writes=sum(s['wrong_write'] for s in changed),
            changed_eligible_preserve=sum(s['conditional_preserve_eligible'] for s in changed),
            changed_post_binding_substitutions=sum(s['post_binding_substitution'] for s in changed))
    x.write(HERE/'MATCHED_CONTROL_AND_STAGE_ANALYSIS.json',dict(status='PASS',models=output,
        analysis_freeze_sha256=x.sha(HERE/'ANALYSIS_FREEZE.json'),scope='prespecified matched 36-world control, not a population causal estimate'))
    print(__import__('json').dumps(output))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('phase',choices=['preflight','post']);args=p.parse_args()
    preflight() if args.phase=='preflight' else post()
