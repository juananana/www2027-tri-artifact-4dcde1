"""Prepare an outcome-independent expansion of the native wording comparison."""
from copy import deepcopy
from datetime import date, timedelta
from pathlib import Path
import hashlib
import importlib.util
import json
import random
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
BASE = HERE.parent
SEED = "tri-wording-scale-20261025"


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


build = load("wording_scale_build", BASE / "web_native_w0_001/build_inventory.py")
design = load("wording_scale_design", BASE / "native_expression_bridge/factorial_design.py")
source = BASE / "native_expression_bridge/runs/alibaba_factorial_20261021/FIXTURES.json"
old = json.loads(source.read_text())
families = sorted({r["selector_family"] for r in old} - {"todoist.highest_priority"})


def generate(dev=False):
    worlds = []
    for family in families:
        prototype = next(r for r in old if r["selector_family"] == family)
        for transition in ("update_competitor", "restore_eligibility"):
            for size in ((4,) if dev else (3, 4, 5, 7)):
                for repeat in ((0,) if dev else (0, 1)):
                    base = f"ws-{'dev' if dev else 'main'}-{family.replace('.', '-')}-{transition}-{size}-{repeat}"
                    rng = random.Random(SEED + base)
                    field, kind = prototype["selector_field"], prototype["selector_value_kind"]
                    direction, app = prototype["selector_direction"], prototype["app"]
                    gap = rng.randrange(2, 9)
                    anchor = rng.randrange(10, 40)
                    if kind == "date":
                        start = date(2027, 6, 1) + timedelta(days=rng.randrange(100))
                        ranks = [(start + timedelta(days=i * gap)).isoformat() for i in range(size + 2)]
                    elif kind == "text":
                        ranks = [chr(65 + i) + " " + hashlib.sha256((base + str(i)).encode()).hexdigest()[:8] for i in range(size + 2)]
                    elif kind == "count":
                        ranks = list(range(1 + repeat, size + 3 + repeat))
                    else:
                        ranks = [anchor + i * gap for i in range(size + 2)]
                    ids = [hashlib.sha256((SEED + base + str(i)).encode()).hexdigest()[:18] for i in range(size)]
                    state = []
                    values = ranks[1:size + 1] if direction == "min" else list(reversed(ranks[1:size + 1]))
                    for i, (entity_id, value) in enumerate(zip(ids, values)):
                        entity = build.base_entity(app, entity_id, 8000 + i)
                        entity["title"] = "Study record " + entity_id
                        entity.update(build.selector_patch(field, kind, value, entity_id))
                        state.append(entity)
                    old_id, competitor = ids[0], ids[-1]
                    if transition == "restore_eligibility":
                        if app == "todoist":
                            state[-1]["done"] = True
                        else:
                            state[-1]["tags"] = []
                    rng.shuffle(state)
                    # Four related unchanged controls per family; not additional independent bases.
                    for changed in ((True, False) if transition == "update_competitor" and repeat == 0 else (True,)):
                        value = (ranks[0] if direction == "min" else ranks[-1]) if changed else (ranks[-1] if direction == "min" else ranks[0])
                        patch = build.selector_patch(field, kind, value, competitor)
                        if transition == "restore_eligibility":
                            if app == "todoist":
                                patch["done"] = False
                            elif field != "tag_count":
                                patch["tags"] = [build.TAG]
                        row = {k: deepcopy(prototype[k]) for k in ("app", "implementation", "selector_family", "selector_text", "selector_field", "selector_direction", "selector_value_kind", "action")}
                        row.update(cluster_id=base + ("-changed" if changed else "-unchanged"),
                                   base_id=base, s0=deepcopy(state), winner_change=changed,
                                   update={"kind": transition, "target_id": competitor, "patch": patch},
                                   transition_family=transition,
                                   display_order="old_first" if repeat == 0 else "old_last",
                                   task_origin="prospective_controlled_generation")
                        row["s1"] = build.apply_update(row["s0"], row["update"])
                        row["old_target_id"] = build.winner(row, row["s0"])
                        row["new_target_id"] = build.winner(row, row["s1"])
                        assert row["old_target_id"] == old_id
                        assert (row["old_target_id"] != row["new_target_id"]) == changed
                        row["gold"] = {"preserve": row["old_target_id"], "reevaluate": row["new_target_id"]}
                        row["expected_final"] = {m: build.expected_after_action(row, t) for m, t in row["gold"].items()}
                        for target in set(row["gold"].values()):
                            assert build.action_valid(app, row["action"], next(e for e in row["s1"] if e["id"] == target))
                        worlds.append(row)
    return worlds


def save(name, value):
    path = HERE / name
    content = json.dumps(value, indent=2, sort_keys=True) + "\n"
    if path.exists():
        if path.read_text() == content:
            return
        assert not (HERE / "RUN_FREEZE_MANIFEST.json").exists(), "Refusing to overwrite frozen inputs"
        assert not list(HERE.glob("runs/*/sessions/*/call_*.request.json")), "Refusing to change inputs after paid entry"
        path.write_text(content)
    else:
        path.write_text(content)


if __name__ == "__main__":
    worlds, dev = generate(), generate(True)
    assert len(worlds) == 140 and len({r["base_id"] for r in worlds}) == 112
    assert sum(r["winner_change"] for r in worlds) == 112
    assert len(dev) == 21 and len({r["base_id"] for r in dev}) == 14
    assert {r["base_id"] for r in worlds}.isdisjoint(r["base_id"] for r in dev)
    cases = []
    for model in ("qwen", "glm"):
        for row in worlds:
            for clarity in ("short", "explicit"):
                for mode in ("preserve", "reevaluate"):
                    cases.append(dict(id=model + "__" + row["cluster_id"] + "__" + clarity + "__" + mode,
                                      model=model, fixture_id=row["cluster_id"], base_id=row["base_id"],
                                      clarity=clarity, mode=mode, display_order=row["display_order"],
                                      instruction=design.instruction(row, clarity, mode)))
    assert len(cases) == 1120
    cases.sort(key=lambda c: hashlib.sha256((SEED + c["id"]).encode()).hexdigest())
    # Independent native model pilot: 16 sessions / 64 requests per configuration.
    requests = len(cases) * 4 // 2 + 64 + 2
    costs = {"qwen": requests * (24000 * 1.2 + 4096 * 7.2) / 1e6,
             "glm": requests * (24000 * 8 + 4096 * 28) / 1e6}
    save("CLUSTERS.json", worlds)
    save("DEV_CLUSTERS.json", dev)
    save("CASES.json", cases)
    save("COST_ENVELOPE.json", dict(models=costs, total_reference_cny=sum(costs.values()),
                                   proposed_hard_cap_cny=850, max_requests_per_model=requests,
                                   pilot_sessions_per_model=16, pilot_requests_per_model=64,
                                   input_tokens_per_request=24000, output_tokens_per_request=4096,
                                   input_text_byte_limit=16000, actual_billing="unknown",
                                   price_sources=["https://help.aliyun.com/zh/model-studio/qwen3-5-397b-a17b", "https://help.aliyun.com/zh/model-studio/glm-5-2"],
                                   price_checked="2026-10-25", paid_authorization="pending_above_standing_CNY20"))
    profiles = [json.dumps({"family": r["selector_family"], "transition": r["transition_family"],
                           "s0": sorted((build.selector_value(e, r["selector_field"], r["selector_value_kind"]), build.eligible(r["app"], e)) for e in r["s0"]),
                           "s1": sorted((build.selector_value(e, r["selector_field"], r["selector_value_kind"]), build.eligible(r["app"], e)) for e in r["s1"])}, sort_keys=True)
                for r in worlds if r["winner_change"]]
    save("ZERO_API_DESIGN.json", dict(status="PASS", main_bases=112, changed_variants=112,
                                      related_unchanged_controls=28, dev_bases=14,
                                      selector_value_profiles=len(set(profiles)), models=2,
                                      sessions=1120, pilot_sessions=32, max_model_requests=4612,
                                      independent_human_review_of_new_instances=False,
                                      templates="unchanged seven unambiguous previously reviewed families",
                                      native_execution="pending representative pilot", model_calls=0))
    files = [HERE / n for n in ("prepare.py", "PROTOCOL.md", "CLUSTERS.json", "DEV_CLUSTERS.json", "CASES.json", "COST_ENVELOPE.json")]
    files += [source, BASE / "web_native_w0_001/build_inventory.py", BASE / "native_expression_bridge/factorial_design.py", BASE / "native_expression_bridge/study.py", BASE / "native_expression_bridge/alibaba_transport.py", BASE / "native_expression_bridge/measurement.py", BASE / "web_native_w1_pilot_001/native_runtime.py", BASE / "web_native_w0_001/native_appworld_check.py"]
    save("INPUT_MANIFEST.json", {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files})
    print(json.dumps(dict(status="DESIGN_READY", bases=112, sessions=1120, reference_cost=costs,
                          total_reference_cny=sum(costs.values()), paid_calls=0)))
