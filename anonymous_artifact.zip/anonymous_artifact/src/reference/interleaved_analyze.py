"""Execute the frozen statistical plan only after complete independent raw audit."""
from pathlib import Path
from collections import Counter,defaultdict
import csv,hashlib,json
import numpy as np
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[3]
def read(p):return json.loads(Path(p).read_text())
def write(name,data):
 p=HERE/name;raw=json.dumps(data,indent=2)+'\n'
 if p.exists():assert p.read_text()==raw,name
 else:p.write_text(raw)
def main():
 audit=read(HERE/'PRIMARY_AUDIT.json');assert audit['status']=='COMPLETE_AUDITED' and audit['assigned']==audit['audited']==1680
 worlds={w['base_id']:w for w in read(HERE/'CLUSTERS.json') if w['winner_change']}
 ids=sorted(worlds);families=sorted({w['selector_family'] for w in worlds.values()});assert len(ids)==112 and len(families)==7
 rows=audit['ledger'];by={(x['arm'],x['world'],x['changed'],x['clarity'],x['mode']):x for x in rows}
 assert len(by)==1680
 rng=np.random.default_rng(2601026);bins=[[i for i,w in enumerate(ids) if worlds[w]['selector_family']==f] for f in families];indices=np.empty((10000,112),dtype=int)
 for i in range(10000):indices[i]=np.concatenate([rng.choice(bins[f],16,replace=True) for f in rng.integers(0,7,7)])
 def interval(x):return np.percentile(np.asarray(x)[indices].mean(axis=1)*100,[2.5,97.5]).tolist()
 outcomes={};vectors={};joints={};pairs={};family={};terminal=defaultdict(Counter)
 for arm in ['A','B','C']:
  for form in ['short','explicit']:
   for mode in ['preserve','reevaluate']:
    for endpoint in ['correct','wrong','no_action','strict','initial']:
     key=f'{arm}/{form}/{mode}/{endpoint}';vec=np.array([by[arm,w,True,form,mode][endpoint] for w in ids]);vectors[key]=vec
     outcomes[key]=dict(count=int(vec.sum()),denominator=112,percent=float(vec.mean()*100),family_world95=interval(vec))
   for endpoint in ['both_actions','both_strict']:
    key=f'{arm}/{form}/pair/{endpoint}';field='correct' if endpoint=='both_actions' else 'strict';vec=np.array([by[arm,w,True,form,'preserve'][field]*by[arm,w,True,form,'reevaluate'][field] for w in ids]);vectors[key]=vec
    pairs[key]=dict(count=int(vec.sum()),denominator=112,percent=float(vec.mean()*100),family_world95=interval(vec))
   cats=Counter()
   for w in ids:
    p,q=[by[arm,w,True,form,m] for m in ['preserve','reevaluate']];a,b=p['action'],q['action'];old,new=p['old'],p['new']
    cat='missing_action' if a is None or b is None else {(old,new):'both_correct',(old,old):'earlier_twice',(new,new):'updated_twice',(new,old):'reversed'}.get((a,b),'other_complete')
    cats[cat]+=1
   assert sum(cats.values())==112;joints[f'{arm}/{form}']=dict(cats)
   family[f'{arm}/{form}']={f:dict(worlds=16,both_actions=sum(by[arm,w,True,form,'preserve']['correct']*by[arm,w,True,form,'reevaluate']['correct'] for w in ids if worlds[w]['selector_family']==f),both_strict=sum(by[arm,w,True,form,'preserve']['strict']*by[arm,w,True,form,'reevaluate']['strict'] for w in ids if worlds[w]['selector_family']==f)) for f in families}
 contrasts={}
 for first,base in [('B','A'),('C','B')]:
  for form in ['short','explicit']:
   for mode,endpoint in [('reevaluate','correct'),('pair','both_actions')]:
    suffix=f'{form}/{mode}/{endpoint}';vec=vectors[f'{first}/{suffix}']-vectors[f'{base}/{suffix}'];key=f'{first}-{base}/{suffix}'
    contrasts[key]=dict(points=float(vec.mean()*100),family_world95=interval(vec),wins=int((vec>0).sum()),losses=int((vec<0).sum()),leave_one_family_out=[float(vec[[worlds[w]['selector_family']!=f for w in ids]].mean()*100) for f in families],primary_predeclared=bool(first=='C' or form=='explicit'))
 # Every related control is kept separate from changed-world intervals.
 controls={}
 for arm in ['A','B','C']:
  for form in ['short','explicit']:
   selected=[x for x in rows if x['arm']==arm and x['clarity']==form and not x['changed']];assert len(selected)==56
   u=sorted({x['world'] for x in selected});assert len(u)==28
   controls[f'{arm}/{form}']=dict(worlds=28,both_actions=sum(by[arm,w,False,form,'preserve']['correct']*by[arm,w,False,form,'reevaluate']['correct'] for w in u),both_strict=sum(by[arm,w,False,form,'preserve']['strict']*by[arm,w,False,form,'reevaluate']['strict'] for w in u),correct=sum(x['correct'] for x in selected),wrong=sum(x['wrong'] for x in selected),no_action=sum(x['no_action'] for x in selected))
 cases={x['id']:x for x in read(HERE/'CASES.json')}
 for row in rows:
  f=HERE/'runs/primary'/row['session'];result=read(f/'RESULT.json');error=result['error'];category='completed_action' if result['action_accepted'] else 'turn_limit' if error=='turn_limit' else 'technical_unavailable' if row['unavailable'] else 'other_failure'
  raw_files=sorted(f.glob('call_*.raw.json'),key=lambda p:int(p.stem.split('_')[1].split('.')[0]))
  if category=='other_failure' and raw_files:
   try:
    cmd=json.loads(read(raw_files[-1])['choices'][0]['message']['content']);tool=cmd.get('tool') if isinstance(cmd,dict) else None
    if not isinstance(cmd,dict):category='format_failure'
    elif row['arm']!='C' and tool!=('list_entities','record_choice','synchronize','perform_action')[len(result['trace'])]:category='wrong_tool'
    else:category='invalid_arguments_or_precondition'
   except (ValueError,TypeError):category='format_failure'
  terminal['/'.join([row['arm'],'changed' if row['changed'] else 'unchanged',row['clarity'],row['mode']])][category]+=1
 usage=Counter();n_req=0;n_resp=0
 for p in HERE.glob('**/*.request.json'):
  if 'zero' in p.parts:continue
  n_req+=1;response=p.with_name(p.name.replace('.request.','.response.'))
  if response.exists():
   u=read(response)['usage'];usage.update(u);n_resp+=1
 observed=(usage['prompt_tokens']*1.2+usage['completion_tokens']*7.2)/1e6;reserved=observed+(n_req-n_resp)*.0582912
 assert reserved<=550 and n_req<=9090
 result=dict(status='COMPLETE_INDEPENDENTLY_AUDITED',assigned=1680,worlds=112,related_controls=28,models=1,new_seed_within_existing_families=True,primary_outcomes=outcomes,paired=pairs,joint=joints,contrasts=contrasts,controls=controls,family=family,terminal_categories=dict(terminal),bootstrap=dict(draws=10000,seed=2601026,unit='families then worlds, paired indices'),cost=dict(requests=n_req,responses=n_resp,reference_observed_cny=observed,reference_with_missing_reserve_cny=reserved,actual_invoice='unknown'),input_sha256={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [HERE/'PRIMARY_AUDIT.json',HERE/'RUN_FREEZE.json',HERE/'ANALYSIS_EXECUTION_FREEZE.json']})
 write('STATISTICAL_RESULT.json',result)
 lines=['# Prospective three-protocol replication','','Complete1680 assigned sessions,112 changed worlds+28 related controls; no semantic/failure retry. Pilot24 excluded. The seven-family inference scope and protocol bundle are unchanged.','', '| Arm/text | Preserve correct/wrong/none | Reevaluate correct/wrong/none | Both actions | Both strict |','|---|---|---|---:|---:|']
 for arm in ['A','B','C']:
  for form in ['short','explicit']:
   vals=['/'.join(str(outcomes[f'{arm}/{form}/{mode}/{ep}']['count']) for ep in ['correct','wrong','no_action']) for mode in ['preserve','reevaluate']]
   lines.append(f"|{arm}/{form}|{vals[0]}|{vals[1]}|{pairs[f'{arm}/{form}/pair/both_actions']['count']}/112|{pairs[f'{arm}/{form}/pair/both_strict']['count']}/112|")
 lines+=['','## Paired contrasts (percentage points)','','| Contrast | Point |95% family/world | Wins/losses |','|---|---:|---|---|']
 for key,x in contrasts.items():lines.append(f"|{key}|{x['points']:.2f}|{x['family_world95']}|{x['wins']}/{x['losses']}|")
 lines+=['','## Joint identities','',json.dumps(joints,indent=2),'','## Controls','',json.dumps(controls,indent=2),'','## Terminal categories','',json.dumps(dict(terminal),indent=2),'','## Costs','',json.dumps(result['cost'],indent=2)]
 (HERE/'REPORT.md').write_text('\n'.join(lines)+'\n')
 with (HERE/'SESSION_LEDGER.csv').open('w') as f:
  writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
 print(json.dumps(dict(status=result['status'],assigned=1680,cost=result['cost'],paired=pairs,contrasts=contrasts),indent=2))
if __name__=='__main__':main()
