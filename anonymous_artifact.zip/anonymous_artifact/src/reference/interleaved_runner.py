"""Frozen native three-protocol replication with a global no-retry queue."""
from pathlib import Path
from collections import Counter
from contextlib import contextmanager
import argparse, ctypes, hashlib, importlib.util, json, multiprocessing, os, re, sqlite3, sys, time
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[3];SOURCE=HERE.parent/'native_expression_bridge'
sys.path.insert(0,str(SOURCE))
import alibaba_transport as provider
from transport import save, reconstruct, clock
from factorial_design import reorder_entities
spec=importlib.util.spec_from_file_location('cf_native_study',SOURCE/'study.py');study=importlib.util.module_from_spec(spec);spec.loader.exec_module(study)
NOTE='Decision recorded; no entity has been modified. After synchronization, call perform_action to carry out the requested modification.'
SYSTEM_C=study.SYSTEM.replace('This measurement uses four steps in order: list_entities, record_choice, synchronize, perform_action.', 'This measurement permits at most eight tool calls, with no fixed order. You may list or record before or after synchronization. Synchronize at most once and perform the action after synchronization; performing the action ends the session. A repeated synchronization or action before synchronization is rejected.').replace('The recorded choice is not enforced or corrected for you.', 'Recording never modifies an entity or performs the action. A later recording may update your decision. The recorded choice is not enforced or corrected for you.')
DB=HERE/'execution.sqlite3';MAX_REQUESTS=9090;PER_REQUEST=.0582912
START_CUTOFF=1793001600 # 2026-10-26 08:00 UTC /16:00 Shanghai
CALL_CUTOFF=1793003400 # 08:30 UTC /16:30 Shanghai
FREEZE_TIME=1793008800 # 10:00 UTC /18:00 Shanghai
# Values are checked against UTC calendar without using a possibly frozen wall clock.
from datetime import datetime,timezone
assert START_CUTOFF==int(datetime(2026,10,26,8,tzinfo=timezone.utc).timestamp())

def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def real_time():
 v=provider.clock.__globals__['Timespec']()
 if ctypes.CDLL(None).clock_gettime(time.CLOCK_REALTIME,ctypes.byref(v)):raise OSError('real time clock unavailable')
 return v.tv_sec+v.tv_nsec/1e9
@contextmanager
def connect():
 c=sqlite3.connect(DB,timeout=60);c.execute('PRAGMA busy_timeout=60000')
 try:yield c
 finally:c.close()
def init_db(phase):
 cases=read(HERE/('PILOT_CASES.json' if phase=='pilot' else 'CASES.json')) if phase!='zero' else []
 with connect() as c:
  c.execute('PRAGMA journal_mode=WAL');c.execute('CREATE TABLE IF NOT EXISTS tasks (id TEXT PRIMARY KEY,phase TEXT,ord INTEGER,status TEXT,worker INTEGER,start REAL,end REAL)')
  c.execute('CREATE TABLE IF NOT EXISTS calls (prefix TEXT PRIMARY KEY,phase TEXT,reserved REAL,end REAL,success INTEGER,reason TEXT,input_tokens INTEGER,output_tokens INTEGER)')
  for i,x in enumerate(cases):c.execute('INSERT OR IGNORE INTO tasks VALUES (?,?,?,\'pending\',NULL,NULL,NULL)',(x['id'],phase,i))
  c.commit()
def stop(reason):
 try:save(HERE/'STOP.json',dict(status='STOP',reason=reason,real_time=real_time()))
 except FileExistsError:pass
def verify():
 assert read(HERE/'BUDGET_APPROVAL.json')['reference_budget_cny']==550
 for rel,h in read(HERE/'RUN_FREEZE.json')['sha256'].items():assert sha(ROOT/rel)==h,rel
 assert not (HERE/'STOP.json').exists(),'global stop exists'
def record_call(prefix,success,reason=None,usage=None):
 with connect() as c:
  c.execute('BEGIN IMMEDIATE');c.execute('UPDATE calls SET end=?,success=?,reason=?,input_tokens=?,output_tokens=? WHERE prefix=?',(real_time(),int(success),reason,(usage or {}).get('prompt_tokens'),(usage or {}).get('completion_tokens'),str(prefix.relative_to(HERE))))
  outcomes=c.execute('SELECT success FROM calls WHERE end IS NOT NULL ORDER BY end DESC LIMIT 50').fetchall();c.commit()
 flags=[bool(x[0]) for x in outcomes]
 if len(flags)>=3 and not any(flags[:3]):stop('three_consecutive_connection_failures')
 if len(flags)==50 and sum(not x for x in flags)>=5:stop('five_connection_failures_in_fifty')
class ModelTruncation(Exception):pass
class TransportFailure(Exception):pass

def paid_call(messages,prefix,phase):
 import httpx
 verify();assert real_time()<CALL_CUTOFF,'paid execution cutoff'
 assert len(json.dumps(messages).encode())<=16000,'input byte bound'
 prefix=Path(prefix);assert not Path(str(prefix)+'.request.json').exists(),'no retransmission'
 with connect() as c:
  c.execute('BEGIN IMMEDIATE');n=c.execute('SELECT count(*) FROM calls').fetchone()[0]
  assert n<MAX_REQUESTS and (n+1)*PER_REQUEST<=550
  c.execute('INSERT INTO calls(prefix,phase,reserved) VALUES (?,?,?)',(str(prefix.relative_to(HERE)),phase,real_time()));c.commit()
 payload=dict(model='qwen3.5-397b-a17b',messages=messages,temperature=0,top_p=1,max_completion_tokens=4096,enable_thinking=False,stream=True,stream_options=dict(include_usage=True))
 save(str(prefix)+'.request.json',dict(endpoint=provider.ENDPOINT,payload=payload,transport='httpx_no_retries'))
 key=provider.credential();events=[];started=clock()
 try:
  with httpx.Client(timeout=httpx.Timeout(120,connect=15),trust_env=True) as client:
   with client.stream('POST',provider.ENDPOINT,json=payload,headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'}) as response:
    save(str(prefix)+'.headers.json',dict(http_status=response.status_code,request_id=response.headers.get('x-request-id'),content_type=response.headers.get('Content-Type')))
    response.raise_for_status()
    with Path(str(prefix)+'.events.jsonl').open('x') as f:
     for line in response.iter_lines():
      e=dict(elapsed_seconds=clock()-started,line=line+'\n');events.append(e);f.write(json.dumps(e)+'\n');f.flush();os.fsync(f.fileno())
      if e['elapsed_seconds']>120:raise TimeoutError('stream duration exceeds120s')
  body=reconstruct(events);save(str(prefix)+'.raw.json',body)
  assert body['model']=='qwen3.5-397b-a17b';usage=body['usage']
  assert 0<usage['prompt_tokens']<=24000 and 0<usage['completion_tokens']<=4096
  save(str(prefix)+'.response.json',dict(usage=usage,returned_model=body['model'],finish_reason=body['choices'][0]['finish_reason'],elapsed_seconds=clock()-started))
  record_call(prefix,True,usage=usage)
  if body['choices'][0]['finish_reason']=='length':raise ModelTruncation('retained truncation')
  assert body['choices'][0]['finish_reason']=='stop'
  return body['choices'][0]['message']['content']
 except ModelTruncation:raise
 except Exception as e:
  allowed=isinstance(e,(httpx.ConnectError,httpx.ConnectTimeout,httpx.ReadTimeout)) and 'CERTIFICATE_VERIFY_FAILED' not in str(e)
  detail=re.sub(r'sk-[A-Za-z0-9_.-]+','[REDACTED]',str(e).replace(key,'[REDACTED]'))
  save(str(prefix)+'.failure.json',dict(category='connection' if allowed else 'infrastructure',error_type=type(e).__name__,reason=detail,persisted_events=len(events),elapsed_seconds=clock()-started))
  record_call(prefix,False,reason=type(e).__name__)
  if not allowed or phase!='primary':stop('noncontinuable_transport_or_pilot_failure')
  raise TransportFailure('retained transport failure; no retry') from None

def evaluate(w,c,prefix,action,final,trace,error):
 actions=[e for e in trace if e['tool']=='perform_action' and e['receipt'].get('status')=='ok']
 sync=any(e['tool']=='synchronize' and e['receipt'].get('synchronized') for e in trace)
 accepted=bool(actions);gold=w['gold'][c['mode']]
 initial=prefix==({'decision':'select','entity_id':w['old_target_id']} if c['mode']=='preserve' else {'decision':'defer','entity_id':None})
 exact=final is not None and sorted(final,key=lambda e:e['id'])==sorted(w['expected_final'][c['mode']],key=lambda e:e['id'])
 correct=bool(accepted and sync and action==gold and exact)
 return dict(initial_correct=initial,synchronized=sync,action_accepted=accepted,correct_action=correct,wrong_write=bool(accepted and action!=gold),no_action=not accepted,captured_exact=exact,strict_success=bool(initial and correct and error is None))

def execute(c,w,phase,worker,native,caller=None,variant=None):
 folder=HERE/'runs'/phase/c['id'];folder.mkdir(parents=True,exist_ok=False)
 save(folder/'CASE.json',c);messages=[dict(role='system',content=SYSTEM_C if c['arm']=='C' else study.SYSTEM),dict(role='user',content=c['instruction'])]
 prefix=action=final=None;trace=[];error=None;unavailable=False;started=real_time()
 try:
  with native.appworld_session(w,'cf_'+c['id'],folder) as service:
   for step in range(8 if c['arm']=='C' else 4):
    try:raw=caller(messages,folder/f'call_{step}',service,step) if caller else paid_call(messages,folder/f'call_{step}',phase)
    except ModelTruncation:error='model_truncation';break
    reverse={str(v):k for k,v in service.ids.items()}
    try:
     cmd=json.loads(raw);assert set(cmd)=={'tool','arguments'};tool=cmd['tool'];args=cmd['arguments'];assert isinstance(args,dict)
     if c['arm']!='C':assert tool==('list_entities','record_choice','synchronize','perform_action')[step]
     assert tool in ('list_entities','record_choice','synchronize','perform_action')
     if tool in ('list_entities','synchronize'):
      assert args=={}
      if tool=='synchronize':assert not service.synced
     elif tool=='record_choice':
      assert set(args)=={'decision','entity_id'}
      assert (args['decision']=='defer' and args['entity_id'] is None) or (args['decision']=='select' and isinstance(args['entity_id'],str) and args['entity_id'] in reverse)
     else:
      assert service.synced and set(args)=={'entity_id'} and isinstance(args['entity_id'],str) and args['entity_id'] in reverse
    except (ValueError,AssertionError,KeyError,TypeError):error='format_or_protocol_rejection';break
    before=service.synced
    if tool=='list_entities':receipt=dict(entities=service.list_entities())
    elif tool=='record_choice':
     if not before and prefix is None:prefix=dict(decision=args['decision'],entity_id=reverse.get(args['entity_id']))
     receipt=dict(recorded=args)
     if c['arm'] in ('B','C'):receipt['execution_note']=NOTE
    elif tool=='synchronize':
     service.synchronize();receipt=dict(synchronized=True,entities=reorder_entities(service.list_entities(),str(service.ids[w['old_target_id']]),c['display_order']))
    else:
     action=reverse[args['entity_id']];save(folder/'action_attempt.json',dict(logical_id=action,native_id=args['entity_id']));receipt=service.perform_action(args['entity_id'])
    event=dict(step=step,tool=tool,arguments=args,synchronized_before=before,receipt=receipt,attempted=tool=='perform_action')
    trace.append(event);save(folder/f'step_{step}.json',event)
    messages += [dict(role='assistant',content=raw),dict(role='user',content='TOOL_RESULT '+json.dumps(receipt))]
    if tool=='perform_action':break
   else:error='turn_limit'
  final=service.final
 except TransportFailure:unavailable=True;error='connection_failure'
 except Exception as e:
  unavailable=True;error='native_or_guard_'+type(e).__name__;stop(error)
  save(folder/'SESSION_FAILURE.json',dict(category='native_or_guard',error_type=type(e).__name__))
 if final is None and (folder/'final.logical.json').exists():final=read(folder/'final.logical.json')
 result=dict(case=c,prefix=prefix,action_id=action,trace=trace,final=final,error=error,unavailable=unavailable,started_real=started,ended_real=real_time(),**evaluate(w,c,prefix,action,final,trace,error))
 save(folder/'RESULT.json',result)
 return result

def native_for(worker):
 study.HERE=HERE/'runtime'/str(worker);study.HERE.mkdir(parents=True,exist_ok=True)
 return study.native()

def worker(phase,index):
 cases={c['id']:c for c in read(HERE/('PILOT_CASES.json' if phase=='pilot' else 'CASES.json'))}
 worlds={w['cluster_id']:w for w in read(HERE/('DEV_CLUSTERS.json' if phase=='pilot' else 'CLUSTERS.json'))}
 native=native_for(index)
 while not (HERE/'STOP.json').exists():
  if real_time()>=CALL_CUTOFF:stop('execution_cutoff');break
  with connect() as db:
   db.execute('BEGIN IMMEDIATE');row=db.execute("SELECT id FROM tasks WHERE phase=? AND status='pending' ORDER BY ord LIMIT 1",(phase,)).fetchone()
   if row is None:db.commit();break
   cid=row[0];db.execute("UPDATE tasks SET status='running',worker=?,start=? WHERE id=?",(index,real_time(),cid));db.commit()
  case=cases[cid]
  try:r=execute(case,worlds[case['fixture_id']],phase,index,native)
  except Exception as e:stop('worker_'+type(e).__name__);raise
  with connect() as db:db.execute("UPDATE tasks SET status='done',end=? WHERE id=?",(real_time(),cid));db.commit()
  print(json.dumps(dict(phase=phase,worker=index,session=cid,completed=True,unavailable=r['unavailable'])),flush=True)
  if r['unavailable'] and not (HERE/'STOP.json').exists():
   until=clock()+15
   while clock()<until:time.sleep(min(1,max(0,until-clock())))

def status():
 with connect() as c:
  tasks=c.execute('SELECT phase,status,count(*) FROM tasks GROUP BY phase,status').fetchall()
  calls=c.execute('SELECT count(*),sum(input_tokens),sum(output_tokens),sum(CASE WHEN success=0 THEN 1 ELSE 0 END) FROM calls').fetchone()
 return dict(tasks=tasks,calls=calls,reserved_reference_cny=calls[0]*PER_REQUEST,stop=read(HERE/'STOP.json') if (HERE/'STOP.json').exists() else None,real_time=real_time())

def freeze():
 assert not (HERE/'RUN_FREEZE.json').exists()
 files=[HERE/n for n in ['prepare.py','runner.py','audit.py','PROTOCOL.md','CLUSTERS.json','DEV_CLUSTERS.json','CASES.json','PILOT_CASES.json','COST_ENVELOPE.json','BUDGET_APPROVAL.json','ZERO_DESIGN.json','ZERO_NATIVE.json']]
 files += [SOURCE/n for n in ['study.py','transport.py','alibaba_transport.py','factorial_design.py','measurement.py']]
 files += [HERE.parent/'web_native_w1_pilot_001/native_runtime.py',HERE.parent/'web_native_w0_001/native_appworld_check.py',HERE.parent/'web_native_w0_001/build_inventory.py',HERE.parent/'wording_scale_20261025/prepare.py']
 save(HERE/'RUN_FREEZE.json',dict(status='FROZEN_BEFORE_PAID_CALLS',sha256={str(p.relative_to(ROOT)):sha(p) for p in files}));verify()

def health():
 init_db('zero');folder=HERE/'health';folder.mkdir(exist_ok=False)
 messages=[dict(role='system',content='Return only the requested JSON.'),dict(role='user',content='Return {"tool":"list_entities","arguments":{}}.')]
 raw=paid_call(messages,folder/'probe_0','health');assert json.loads(raw)==dict(tool='list_entities',arguments={})
 messages += [dict(role='assistant',content=raw),dict(role='user',content='TOOL_RESULT {"entities":[{"persistent_id":"101"}]}. Return {"tool":"record_choice","arguments":{"decision":"defer","entity_id":null}}.')]
 raw=paid_call(messages,folder/'probe_1','health');assert json.loads(raw)==dict(tool='record_choice',arguments=dict(decision='defer',entity_id=None))
 save(HERE/'HEALTH_PASS.json',dict(status='PASS',requests=2))

def run(phase):
 verify();assert read(HERE/'HEALTH_PASS.json')['status']=='PASS'
 if phase=='primary':assert read(HERE/'PILOT_GO.json')['decision']=='GO' and real_time()<START_CUTOFF
 init_db(phase);started=real_time();ctx=multiprocessing.get_context('spawn');ps=[ctx.Process(target=worker,args=(phase,i)) for i in range(3)]
 for p in ps:p.start()
 for p in ps:p.join()
 save(HERE/(phase.upper()+'_RUN_COMPLETE.json'),dict(started_real=started,ended_real=real_time(),exitcodes=[p.exitcode for p in ps],status=status()))
 print(json.dumps(status()),flush=True)

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('command',choices=['freeze','health','pilot','primary','status']);a=p.parse_args()
 if a.command=='freeze':freeze()
 elif a.command=='health':health()
 elif a.command=='status':print(json.dumps(status()))
 else:run(a.command)
