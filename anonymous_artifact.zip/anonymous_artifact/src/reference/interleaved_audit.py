"""Independent raw/state checks; native zero-API qualification and technical GO."""
from pathlib import Path
from collections import Counter,defaultdict
import argparse,hashlib,importlib.util,json,os,sys
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[3]
sys.path.insert(0,str(HERE));import runner as r
spec=importlib.util.spec_from_file_location('cf_independent_verifier',ROOT/'www2027/reproducibility/verify_wording_scale.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
read=r.read;save=r.save

def audit_case(case,w,phase):
 f=HERE/'runs'/phase/case['id'];x=read(f/'RESULT.json');assert x['case']==case
 assert v.winner(w,w['s0'])==w['old_target_id'] and v.winner(w,w['s1'])==w['new_target_id']
 trace=x['trace'];cmds={};requests=list(f.glob('call_*.request.json'))
 for req in requests:
  i=int(req.stem.split('_')[1].split('.')[0]);payload=read(req)['payload']
  assert payload['messages'][:2]==[dict(role='system',content=r.SYSTEM_C if case['arm']=='C' else r.study.SYSTEM),dict(role='user',content=case['instruction'])]
  assert (payload['temperature'],payload['top_p'],payload['max_completion_tokens'],payload['enable_thinking'])==(0,1,4096,False)
  for e in trace:
   if e['step']<i:
    assert json.loads(payload['messages'][2+2*e['step']]['content'])==dict(tool=e['tool'],arguments=e['arguments'])
    assert json.loads(payload['messages'][3+2*e['step']]['content'].removeprefix('TOOL_RESULT '))==e['receipt']
  raw=req.with_name(req.name.replace('.request.','.raw.'))
  if raw.exists():
   body=read(raw);events=req.with_name(req.name.replace('.request.json','.events.jsonl'))
   if events.exists():assert r.reconstruct([json.loads(line) for line in events.read_text().splitlines()])==body
   try:cmds[i]=json.loads(body['choices'][0]['message']['content'])
   except (ValueError,TypeError):pass
 ids0=read(f/'native_ids.initial.json') if (f/'native_ids.initial.json').exists() else {}
 ids1=read(f/'native_ids.after_update.json') if (f/'native_ids.after_update.json').exists() else ids0
 rev0={str(z):k for k,z in ids0.items()};rev1={str(z):k for k,z in ids1.items()};pre=None;sync=False;accepted=False;action=None
 for i,e in enumerate(trace):
  assert e['step']==i and e==read(f/f'step_{i}.json')
  assert cmds[i]==dict(tool=e['tool'],arguments=e['arguments'])
  assert bool(e['synchronized_before'])==sync
  if case['arm']!='C':assert e['tool']==('list_entities','record_choice','synchronize','perform_action')[i]
  if e['tool'] in ('list_entities','synchronize'):
   if e['tool']=='synchronize':assert not sync;sync=True
   rev=rev1 if sync else rev0
   observed=[dict(id=rev[a['persistent_id']],**{k:z for k,z in a.items() if k!='persistent_id'}) for a in e['receipt']['entities']]
   assert v.canonical(observed)==v.canonical(w['s1'] if sync else w['s0'])
  elif e['tool']=='record_choice':
   if not sync and pre is None:pre=dict(decision=e['arguments']['decision'],entity_id=rev0.get(str(e['arguments']['entity_id'])))
   expected=dict(recorded=e['arguments'])
   if case['arm'] in ('B','C'):expected['execution_note']=r.NOTE
   assert e['receipt']==expected
  else:
   assert sync and i==len(trace)-1;accepted=e['receipt']['status']=='ok';action=rev1[e['arguments']['entity_id']]
   receipt=read(f/'action.receipt.json');assert receipt['logical_id']==action
 final=read(f/'final.logical.json') if (f/'final.logical.json').exists() else None
 if accepted:assert v.canonical(final)==v.apply_action(w,action)
 elif final is not None:assert v.canonical(final)==v.canonical(w['s1'] if sync else w['s0'])
 initial=pre==({'decision':'select','entity_id':w['old_target_id']} if case['mode']=='preserve' else {'decision':'defer','entity_id':None})
 correct=bool(accepted and sync and action==w['gold'][case['mode']] and v.canonical(final)==v.canonical(w['expected_final'][case['mode']]))
 assert x['prefix']==pre and x['action_id']==action
 assert x['initial_correct']==initial and x['correct_action']==correct and x['wrong_write']==bool(accepted and action!=w['gold'][case['mode']])
 assert x['strict_success']==bool(initial and correct and x['error'] is None)
 return dict(session=case['id'],arm=case['arm'],world=w['base_id'],family=w['selector_family'],changed=w['winner_change'],clarity=case['clarity'],mode=case['mode'],old=w['old_target_id'],new=w['new_target_id'],action=action,correct=int(correct),wrong=int(accepted and not correct),no_action=int(not accepted),strict=int(x['strict_success']),initial=int(initial),requests=len(requests),unavailable=x['unavailable'],error=x['error'])

def audit(phase):
 cases=read(HERE/('PILOT_CASES.json' if phase=='pilot' else 'CASES.json'));worlds={w['cluster_id']:w for w in read(HERE/('DEV_CLUSTERS.json' if phase=='pilot' else 'CLUSTERS.json'))}
 rows=[];missing=[]
 for c in cases:
  if (HERE/'runs'/phase/c['id']/'RESULT.json').exists():rows.append(audit_case(c,worlds[c['fixture_id']],phase))
  else:missing.append(c['id'])
 groups=defaultdict(Counter)
 for row in rows:
  key='/'.join([row['arm'],'changed' if row['changed'] else 'unchanged',row['clarity'],row['mode']]);groups[key].update({k:row[k] for k in ['correct','wrong','no_action','strict','initial','requests','unavailable']});groups[key]['assigned']+=1
 out=dict(status='COMPLETE_AUDITED' if not missing else 'INCOMPLETE',phase=phase,assigned=len(cases),audited=len(rows),missing=missing,groups=dict(groups),ledger=rows,model_calls_from_audit=0)
 path=HERE/(phase.upper()+'_AUDIT.json')
 if path.exists():assert read(path)==out
 else:save(path,out)
 return out

def zero():
 before=os.environ.get('HOME');native=r.native_for('zero');cases=read(HERE/'PILOT_CASES.json');worlds={w['cluster_id']:w for w in read(HERE/'DEV_CLUSTERS.json')};checks=[]
 # All arm/form/mode/application cells; C exercises a fifth recording call.
 for c in cases:
  w=worlds[c['fixture_id']]
  def mock(messages,prefix,service,step):
   old=str(service.ids[w['old_target_id']]);gold=str(service.ids[w['gold'][c['mode']]])
   commands=[dict(tool='list_entities',arguments={}),dict(tool='record_choice',arguments=dict(decision='select' if c['mode']=='preserve' else 'defer',entity_id=old if c['mode']=='preserve' else None)),dict(tool='synchronize',arguments={})]
   if c['arm']=='C':commands.append(dict(tool='record_choice',arguments=dict(decision='select',entity_id=gold)))
   commands.append(dict(tool='perform_action',arguments=dict(entity_id=gold)))
   raw=json.dumps(commands[step]);payload=dict(model='qwen3.5-397b-a17b',messages=messages,temperature=0,top_p=1,max_completion_tokens=4096,enable_thinking=False)
   save(str(prefix)+'.request.json',dict(payload=payload,qualification_only=True));save(str(prefix)+'.raw.json',dict(choices=[dict(message=dict(content=raw))],qualification_only=True));return raw
  x=r.execute(c,w,'zero','zero',native,caller=mock);assert x['strict_success']
  checks.append(audit_case(c,w,'zero'))
 assert os.environ.get('HOME')==before
 # Pure scorer edge cases: wrong targets, no action, incomplete initial evidence.
 w=worlds[cases[0]['fixture_id']];c=dict(cases[0],mode='reevaluate');wrong=w['old_target_id']
 trace=[dict(tool='synchronize',receipt={'synchronized':True}),dict(tool='perform_action',receipt={'status':'ok'})]
 assert r.evaluate(w,c,None,wrong,v.apply_action(w,wrong),trace,None)['wrong_write']
 assert r.evaluate(w,c,None,None,w['s1'],trace[:1],'turn_limit')['no_action']
 t=r.evaluate(w,c,None,w['new_target_id'],w['expected_final']['reevaluate'],trace,None);assert t['correct_action'] and not t['strict_success']
 save(HERE/'ZERO_NATIVE.json',dict(status='PASS',native_sessions=len(checks),all_three_arms=True,C_post_refresh_record_admitted=True,scorer_edge_cases=3,model_calls=0,HOME_unchanged=True,checked_sessions=[x['session'] for x in checks]))
 print('PASS:24 native zero-API sessions, C extra recording and3 scoring edge cases')

def gate():
 r.verify();a=audit('pilot');assert a['status']=='COMPLETE_AUDITED' and not any(x['unavailable'] for x in a['ledger'])
 run=read(HERE/'PILOT_RUN_COMPLETE.json');assert run['exitcodes']==[0,0,0] and not (HERE/'STOP.json').exists()
 with r.connect() as c:vals=c.execute("SELECT reserved,end,success FROM calls WHERE phase='pilot'").fetchall()
 assert vals and all(x[2]==1 for x in vals)
 # Reserve maximum future calls and observed native overhead, with factor two.
 call_mean=sum(z-y for y,z,_ in vals)/len(vals)
 total_session=sum(read(HERE/'runs/pilot'/x['session']/'RESULT.json')['ended_real']-read(HERE/'runs/pilot'/x['session']/'RESULT.json')['started_real'] for x in a['ledger'])
 native_per_session=max(0,(total_session-sum(z-y for y,z,_ in vals))/len(a['ledger']))
 formal_seconds=2*(8960*call_mean+1680*native_per_session)/3
 now=r.real_time();decision='GO' if now<r.START_CUTOFF and now+formal_seconds<r.CALL_CUTOFF and now+formal_seconds+5400<r.FREEZE_TIME else 'NO_GO_TIME'
 out=dict(decision=decision,pilot_sessions=24,pilot_requests=len(vals),semantic_success_not_a_gate=True,mean_call_seconds=call_mean,native_overhead_seconds_per_session=native_per_session,conservative_formal_seconds=formal_seconds,audit_reserve_seconds=5400,seconds_until_call_cutoff=r.CALL_CUTOFF-now,seconds_until_scientific_freeze=r.FREEZE_TIME-now,recorded_real=now,reference_upper_cny=read(HERE/'COST_ENVELOPE.json')['reference_upper_cny'])
 save(HERE/'PILOT_GO.json',out);print(json.dumps(out,indent=2))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('command',choices=['zero','pilot','primary','gate']);a=p.parse_args()
 if a.command=='zero':zero()
 elif a.command=='gate':gate()
 else:
  x=audit(a.command);print(json.dumps({k:z for k,z in x.items() if k!='ledger'},indent=2))
