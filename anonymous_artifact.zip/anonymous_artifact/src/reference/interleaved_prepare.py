"""Prepare a new-seed, three-protocol replication before any model calls."""
from pathlib import Path
import hashlib, importlib.util, json, random, sys
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[3];A=HERE.parent/'wording_scale_20261025';SOURCE=HERE.parent/'native_expression_bridge'
sys.path.insert(0,str(SOURCE))
from factorial_design import instruction
spec=importlib.util.spec_from_file_location('new_seed_generator',A/'prepare.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
g.SEED='tri-confirmatory-protocol-20261026-new-seed'
def save(name,x):
 p=HERE/name;raw=json.dumps(x,indent=2,sort_keys=True)+'\n'
 if p.exists():assert p.read_text()==raw,name
 else:p.write_text(raw)
def make(dev):
 rows=g.generate(dev)
 for w in rows:
  w['base_id']=w['base_id'].replace('ws-','cf-',1);w['cluster_id']=w['cluster_id'].replace('ws-','cf-',1)
  w['task_origin']='new_seed_prospective_replication'
 return rows
worlds=make(False);dev=make(True)
assert len(worlds)==140 and sum(w['winner_change'] for w in worlds)==112
assert len({w['base_id'] for w in worlds})==112
old=json.loads((A/'CLUSTERS.json').read_text())
assert {e['id'] for w in worlds for e in w['s0']}.isdisjoint(e['id'] for w in old for e in w['s0'])
for w in worlds+dev:
 assert g.build.winner(w,w['s0'])==w['old_target_id']
 assert g.build.winner(w,w['s1'])==w['new_target_id']
 for mode,t in w['gold'].items():assert g.build.action_valid(w['app'],w['action'],next(e for e in w['s1'] if e['id']==t))
def cases(rows):
 out=[]
 # Each world/update is a block. All12 protocol x wording x timing sessions
 # are randomly ordered within a block; block order is independently random.
 ordered=sorted(rows,key=lambda w:hashlib.sha256(('blocks:'+w['cluster_id']).encode()).hexdigest())
 for w in ordered:
  block=[]
  for arm in ['A','B','C']:
   for form in ['short','explicit']:
    for mode in ['preserve','reevaluate']:
     block.append(dict(id='qwen__'+w['cluster_id']+'__'+arm+'__'+form+'__'+mode,model='qwen',arm=arm,fixture_id=w['cluster_id'],base_id=w['base_id'],clarity=form,mode=mode,display_order=w['display_order'],instruction=instruction(w,form,mode)))
  random.Random('interleave:'+w['cluster_id']).shuffle(block);out.extend(block)
 return out
primary=cases(worlds)
pilot_worlds=[next(w for w in dev if w['app']==app and w['winner_change'] and w['transition_family']=='update_competitor') for app in ['todoist','simple_note']]
pilot=cases(pilot_worlds)
assert len(primary)==1680 and len(pilot)==24
save('CLUSTERS.json',worlds);save('DEV_CLUSTERS.json',dev);save('CASES.json',primary);save('PILOT_CASES.json',pilot)
max_requests=560*(4+4+8)+8*(4+4+8)+2
per_request=(24000*1.2+4096*7.2)/1e6
assert max_requests==9090 and max_requests*per_request<550
save('COST_ENVELOPE.json',dict(max_requests=max_requests,input_token_envelope=24000,completion_cap=4096,input_message_byte_limit=16000,input_rate_cny_per_million=1.2,output_rate_cny_per_million=7.2,reference_upper_cny=max_requests*per_request,approved_cap_cny=550,price_checked='2026-10-26',price_source='https://help.aliyun.com/zh/model-studio/qwen3-5-397b-a17b',actual_billing='unknown'))
save('BUDGET_APPROVAL.json',dict(approved_by='human_user',reference_budget_cny=550,models=['qwen3.5-397b-a17b'],scope='112 new-seed worlds +28 related controls; A terse four-turn, B clarified four-turn, C clarified flexible <=8-turn; randomized interleaving; qualification first; all outcomes retained',source='Direct user reply in this chat: 增加上述实验，预算上限550元',not_authorized=['additional models','2x2 instruction factorial','retrying a failed or semantic request']))
save('ZERO_DESIGN.json',dict(status='PASS',worlds=112,related_controls=28,families=7,primary_sessions=1680,pilot_sessions=24,old_ids_disjoint=True,selector_and_action_checks=True,models=1,new_family_generalization=False,independent_human_validation_of_new_instances=False,model_calls=0))
print(json.dumps(dict(status='DESIGN_READY',primary_sessions=1680,pilot_sessions=24,max_requests=max_requests,reference_upper_cny=max_requests*per_request)))
