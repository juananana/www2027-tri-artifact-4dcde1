"""Read-only reconstruction of both segments; writes derived reports only."""
from pathlib import Path
import importlib.util,sys,json,hashlib,sqlite3
HERE=Path(__file__).resolve().parent
ORIG=HERE.parent/'confirmatory_protocol_20261026'
ROOT=HERE.parents[3]
OUT=HERE/'combined_analysis';OUT.mkdir(exist_ok=True)
sys.dont_write_bytecode=True
sys.path.insert(0,str(ORIG))
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
a=load('original_audit',ORIG/'audit.py')
read=lambda p:json.loads(p.read_text())
rows=[];locations={};cases=read(ORIG/'CASES.json');worlds={w['cluster_id']:w for w in read(ORIG/'CLUSTERS.json')}
for rel,h in read(ORIG/'RUN_FREEZE.json')['sha256'].items():assert hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==h,rel
for case in cases:
 paths=[(ORIG,'primary'),(HERE,'continuation')]
 found=[(root,phase) for root,phase in paths if (root/'runs'/phase/case['id']/'RESULT.json').exists()]
 assert len(found)==1,(case['id'],found)
 root,phase=found[0];a.HERE=root
 rows.append(a.audit_case(case,worlds[case['fixture_id']],phase))
 locations[case['id']]=str(root/'runs'/phase/case['id'])
assert len(rows)==1680
cost={'requests':0,'responses':0,'input':0,'output':0,'failures':0}
for root,db in [(ORIG,'execution.sqlite3'),(HERE,'recovery.sqlite3')]:
 with sqlite3.connect(f'file:{root/db}?mode=ro',uri=True) as c:
  vals=c.execute('select count(*),sum(success=1),sum(input_tokens),sum(output_tokens),sum(success=0) from calls').fetchone()
  for key,val in zip(cost,vals):cost[key]+=val or 0
cost['reference_observed_cny']=(cost['input']*1.2+cost['output']*7.2)/1e6
cost['reference_with_missing_reserve_cny']=cost['reference_observed_cny']+cost['failures']*.0582912
cost['full_reservation_cny']=cost['requests']*.0582912
cost['actual_invoice']='unknown'
assert cost['full_reservation_cny']<550
out=dict(status='COMPLETE_AUDITED',assigned=1680,audited=len(rows),ledger=rows,source_locations=locations,cost=cost,scope='Combined original and amended recovery; original stopped records retained')
(OUT/'PRIMARY_AUDIT.json').write_text(json.dumps(out,indent=2)+'\n')
source=(ORIG/'analyze_confirmatory.py').read_text()
source=source.replace("read(HERE/'CLUSTERS.json')","read(ORIG/'CLUSTERS.json')").replace("read(HERE/'CASES.json')","read(ORIG/'CASES.json')")
source=source.replace("f=HERE/'runs/primary'/row['session']", "f=Path(audit['source_locations'][row['session']])")
start=source.index(' usage=Counter();n_req=0;n_resp=0')
end=source.index(' result=dict(',start)
source=source[:start]+" n_req=cost['requests'];n_resp=cost['responses'];observed=cost['reference_observed_cny'];reserved=cost['reference_with_missing_reserve_cny']\n"+source[end:]
source=source.replace("HERE/'RUN_FREEZE.json'","ORIG/'RUN_FREEZE.json'").replace("HERE/'ANALYSIS_EXECUTION_FREEZE.json'","ORIG/'ANALYSIS_EXECUTION_FREEZE.json'")
source=source.replace("if __name__=='__main__':main()",'')
namespace={'__file__':str(ORIG/'analyze_confirmatory.py'),'__name__':'derived_analysis'}
exec(compile(source,str(ORIG/'analyze_confirmatory.py'),'exec'),namespace)
namespace.update(HERE=OUT,ORIG=ORIG,ROOT=ROOT,cost=cost)
namespace['main']()

# Make the administrative deviations explicit in the derived report.
report=OUT/'REPORT.md'
text=report.read_text()
text=text.replace('The seven-family inference scope and protocol bundle are unchanged.', 'The seven-family scientific scope is unchanged. Execution includes the stopped original segment and amended recovery segments; this is not an uninterrupted execution of the original frozen protocol.')
text += "\n## Recovery and interpretation limits\n\n32 connection-failure sessions remain in assigned denominators (3 original, 29 recovery). Original outputs remain unchanged. Recovery changed worker concurrency and reset the connection window after a recorded stop. Runtime-gate attempts occurred before model requests and were retained separately; their assignments were subsequently executed. These deviations must accompany any confirmatory interpretation. The historical B experiment remains exploratory.\n\nThis A/B/C experiment does not supply Qwen397B results on the separate original target-selection diagnostic panel. Recording a choice inside an action session is not a substitute for running that panel. The second requested cross-evaluation bridge remains uncompleted.\n"
report.write_text(text)
