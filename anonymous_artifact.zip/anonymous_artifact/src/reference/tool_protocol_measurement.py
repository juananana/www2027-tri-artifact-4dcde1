"""Validate native instruction inputs and score observable execution stages."""


def instruction(row, form, mode):
    if mode not in ("preserve", "reevaluate"):
        raise ValueError("unknown timing mode")
    if row["app"] == "todoist":
        selector = "the incomplete Todoist task due earliest"
        noun = "task"
        action = "postpone it by one day"
    elif row["app"] == "simple_note":
        tag_sets = [set(entity["tags"]) for entity in row["s0"] if not entity["deleted"] and entity["tags"]]
        tags = set.intersection(*tag_sets)
        if len(tags) != 1:
            raise ValueError("expected one observed shared experiment tag")
        selector = "the alphabetically first Simple Note note tagged " + next(iter(tags))
        noun = "note"
        action = "append 'reviewed' to it"
    else:
        raise ValueError("unsupported application")
    if form == "short":
        return f"Find {selector} in the current list. Synchronize the service, then {action} using the {noun} you found." if mode == "preserve" else f"After the service is synchronized, find {selector} and {action}."
    if form != "expanded" or mode not in ("preserve", "reevaluate"):
        raise ValueError("unknown expression or timing mode")
    return f"Choose {selector} from the pre-synchronization list. After synchronization, {action} on that same entity, even if a different entity now matches. Modify no other entity." if mode == "preserve" else f"Leave the target undecided before synchronization. After synchronization, choose {selector} from the updated list and {action}. Modify no other entity."


def changed_entities(before, after):
    initial = {entity["id"]: entity for entity in before}
    final = {entity["id"]: entity for entity in after}
    return sorted(entity_id for entity_id in initial.keys() | final.keys() if initial.get(entity_id) != final.get(entity_id))


def score(row, mode, prefix, action_id, final, trace, error=None):
    synchronized = any(event["tool"] == "synchronize" and event["receipt"].get("synchronized") is True for event in trace)
    prefix_events = [event for event in trace if event["tool"] == "record_choice"]
    pre_update_prefix = bool(prefix_events and prefix_events[0].get("synchronized_before") is False)
    prefix_expected = {"decision": "select", "entity_id": row["old_target_id"]} if mode == "preserve" else {"decision": "defer", "entity_id": None}
    prefix_correct = pre_update_prefix and prefix == prefix_expected
    old_entity = next((entity for entity in row["s1"] if entity["id"] == row["old_target_id"]), None)
    old_valid = bool(old_entity) and (not old_entity["done"] if row["app"] == "todoist" else not old_entity["deleted"] and bool(old_entity["tags"]))
    eligible = bool(mode == "preserve" and prefix_correct and synchronized and old_valid and row["old_target_id"] != row["new_target_id"])
    actions = [event for event in trace if event["tool"] == "perform_action" and event.get("attempted") is True]
    action_attempted = bool(actions)
    action_accepted = bool(actions and actions[-1]["receipt"].get("status") == "ok")
    baseline = row["s1"] if synchronized else row["s0"]
    changed = changed_entities(baseline, final)
    wrong_changes = [entity_id for entity_id in changed if entity_id != row["gold"][mode]]
    proposal_wrong = action_id is not None and action_id != row["gold"][mode]
    captured_exact = final == sorted(row["expected_final"][mode], key=lambda entity: entity["id"])
    final_target_correct = action_attempted and action_accepted and action_id == row["gold"][mode]
    return {
        "prefix_correct": prefix_correct,
        "synchronization_observed": synchronized,
        "target_correct": final_target_correct,
        "captured_state_exact": captured_exact,
        "proposed_wrong_target": proposal_wrong,
        "wrong_target_action_attempted": bool(proposal_wrong and action_attempted),
        "wrong_entity_write": bool(wrong_changes),
        "wrong_changed_entity_ids": wrong_changes,
        "action_attempted": action_attempted,
        "action_accepted": action_accepted,
        "conditional_preserve_eligible": eligible,
        "post_binding_substitution_attempt": bool(eligible and action_attempted and action_id == row["new_target_id"]),
        "post_binding_substitution_write": bool(eligible and row["new_target_id"] in wrong_changes),
        "strict_success": bool(prefix_correct and synchronized and final_target_correct and captured_exact and error is None),
    }
