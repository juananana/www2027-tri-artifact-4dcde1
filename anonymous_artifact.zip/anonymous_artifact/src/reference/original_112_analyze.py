"""World-paired endpoints for the fixed primary panel; never pool pilot outcomes."""
from collections import defaultdict
from pathlib import Path
import csv
import json
import numpy as np

HERE = Path(__file__).resolve().parent


def summarize(report):
    if report["status"] != "COMPLETE":
        return dict(status="PARTIAL", assigned=report["assigned_sessions"], completed=report["completed_sessions"],
                    groups=report["groups"], comparative_conclusion=False)
    worlds = defaultdict(dict)
    for row in report["ledger"]:
        if row["changed"]:
            key = row["world"]
            worlds[key][row["clarity"], row["mode"]] = row
    assert len(worlds) == 112 and all(len(w) == 4 for w in worlds.values())
    families = defaultdict(list)
    for key, members in sorted(worlds.items()):
        pshort, pexplicit = members["short", "preserve"], members["explicit", "preserve"]
        rshort, rexplicit = members["short", "reevaluate"], members["explicit", "reevaluate"]
        correct = lambda r: r["outcome"] == "correct_action"
        delta = [int(pshort["outcome"] == "wrong_write") - int(pexplicit["outcome"] == "wrong_write"),
                 int(correct(rexplicit)) - int(correct(rshort)),
                 int(correct(pexplicit) and correct(rexplicit)) - int(correct(pshort) and correct(rshort))]
        families[pshort["family"]].append(delta)
    assert len(families) == 7 and all(len(v) == 16 for v in families.values())
    arrays = {f: np.array(v) for f, v in sorted(families.items())}
    rng = np.random.default_rng(20261025)
    fixed = np.zeros((10000, 3))
    keys = list(arrays)
    for f in keys:
        a = arrays[f]
        fixed += a[rng.integers(len(a), size=(10000, len(a)))].mean(axis=1) / len(keys)
    hierarchy = []
    for _ in range(10000):
        sample = []
        for f in rng.choice(keys, len(keys), replace=True):
            a = arrays[f]
            sample.append(a[rng.integers(len(a), size=len(a))])
        hierarchy.append(np.concatenate(sample).mean(axis=0))
    a = np.concatenate(list(arrays.values()))
    output = dict(status="COMPLETE", primary_worlds=112, authored_families=7,
                  unit="world; configurations and controls are not additional independent bases",
                  bootstrap_draws=10000, bootstrap_seed=20261025,
                  groups=report["groups"], comparisons={})
    for i, name in enumerate(("Preserve wrong writes: short minus explicit", "Reevaluate correct action: explicit minus short", "Both correct actions: explicit minus short")):
        leave = [np.concatenate([x for f, x in arrays.items() if f != omitted]).mean(axis=0)[i] for omitted in keys]
        output["comparisons"][name] = dict(difference_percentage_points=float(a.mean(axis=0)[i] * 100),
            fixed_family_world_bootstrap_95_points=(np.quantile(fixed[:, i], [.025, .975]) * 100).tolist(),
            family_world_bootstrap_95_points=(np.quantile(np.asarray(hierarchy)[:, i], [.025, .975]) * 100).tolist(),
            leave_one_family_out_range_points=[float(min(leave) * 100), float(max(leave) * 100)],
            family_differences_points={f: float(x.mean(axis=0)[i] * 100) for f, x in arrays.items()})
    return output


if __name__ == "__main__":
    reports = {}
    for model in ("qwen", "glm"):
        path = HERE / "runs" / model / "PRIMARY_AUDIT.json"
        if path.exists():
            reports[model] = summarize(json.loads(path.read_text()))
    assert reports, "No independent primary audit yet"
    result = dict(scope="Prospective new-world replication, separate from historical and pilot panels", models=reports)
    target = HERE / "COMPARISON.json"
    if target.exists():
        assert json.loads(target.read_text()) == result
    else:
        target.write_text(json.dumps(result, indent=2) + "\n")
    with (HERE / "OUTCOMES.csv").open("x", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["model", "condition", "assigned", "correct_action", "wrong_write", "no_action", "missing", "unknown_state"])
        for model, report in reports.items():
            for key, counts in sorted(report["groups"].items()):
                writer.writerow([model, key] + [counts.get(k, 0) for k in ("assigned", "correct_action", "wrong_write", "no_action", "missing", "unknown_state")])
    lines = ["# Native wording expansion", "", "The primary worlds, controls, configurations, pilot, and retained historical panel are reported separately.", ""]
    for model, report in reports.items():
        lines += ["## " + model, "", "Status: " + report["status"], "", "| Condition | Assigned | Correct action | Wrong write | No action | Missing |", "|---|---:|---:|---:|---:|---:|"]
        for key, counts in sorted(report["groups"].items()):
            lines.append("| " + key + " | " + " | ".join(str(counts.get(k, 0)) for k in ("assigned", "correct_action", "wrong_write", "no_action", "missing")) + " |")
        for name, values in report.get("comparisons", {}).items():
            lines += ["", name + ": " + str(round(values["difference_percentage_points"], 2)) + " percentage points; descriptive family/world interval " + str(values["family_world_bootstrap_95_points"]) + "."]
        lines += ["", "Intervals describe resampling of the seven authored families. They do not establish production prevalence or unseen-family performance.", ""]
    (HERE / "REPORT.md").write_text("\n".join(lines))
    print(json.dumps(result, indent=2))
