"""Recompute the current 112-world interleaved statistics from normalized rows."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np


def read(path: Path):
    return json.loads(path.read_text())


def rows(path: Path):
    return [json.loads(line) for line in path.read_text().splitlines() if line]


def recompute(root: Path):
    worlds_all = read(root / "data/interleaved_112/worlds.json")
    worlds = {world["base_id"]: world for world in worlds_all if world["winner_change"]}
    sessions = rows(root / "results/interleaved_112/sessions.jsonl")
    scores = [entry["score"] for entry in sessions]
    by = {(row["arm"], row["world"], row["changed"], row["clarity"], row["mode"]): row for row in scores}
    ids = sorted(worlds)
    families = sorted({world["selector_family"] for world in worlds.values()})
    assert len(ids) == 112 and len(families) == 7 and len(by) == 1680
    bins = [[index for index, world_id in enumerate(ids) if worlds[world_id]["selector_family"] == family] for family in families]
    rng = np.random.default_rng(2601026)
    indices = np.empty((10000, 112), dtype=int)
    for draw in range(10000):
        indices[draw] = np.concatenate([rng.choice(bins[family_index], 16, replace=True) for family_index in rng.integers(0, 7, 7)])

    def interval(vector):
        return np.percentile(np.asarray(vector)[indices].mean(axis=1) * 100, [2.5, 97.5]).tolist()

    outcomes = {}
    vectors = {}
    paired = {}
    joint = {}
    for arm in ("A", "B", "C"):
        for form in ("short", "explicit"):
            for mode in ("preserve", "reevaluate"):
                for endpoint in ("correct", "wrong", "no_action", "strict", "initial"):
                    key = f"{arm}/{form}/{mode}/{endpoint}"
                    vector = np.array([by[arm, world_id, True, form, mode][endpoint] for world_id in ids])
                    vectors[key] = vector
                    outcomes[key] = {
                        "count": int(vector.sum()),
                        "denominator": 112,
                        "percent": float(vector.mean() * 100),
                        "family_world95": interval(vector),
                    }
            for endpoint, field in (("both_actions", "correct"), ("both_strict", "strict")):
                key = f"{arm}/{form}/pair/{endpoint}"
                vector = np.array([by[arm, world_id, True, form, "preserve"][field] * by[arm, world_id, True, form, "reevaluate"][field] for world_id in ids])
                vectors[key] = vector
                paired[key] = {
                    "count": int(vector.sum()),
                    "denominator": 112,
                    "percent": float(vector.mean() * 100),
                    "family_world95": interval(vector),
                }
            categories = {name: 0 for name in ("both_correct", "earlier_twice", "updated_twice", "reversed", "other_complete", "missing_action")}
            for world_id in ids:
                preserve = by[arm, world_id, True, form, "preserve"]
                reevaluate = by[arm, world_id, True, form, "reevaluate"]
                a, b, old, new = preserve["action"], reevaluate["action"], preserve["old"], preserve["new"]
                category = "missing_action" if a is None or b is None else {
                    (old, new): "both_correct",
                    (old, old): "earlier_twice",
                    (new, new): "updated_twice",
                    (new, old): "reversed",
                }.get((a, b), "other_complete")
                categories[category] += 1
            joint[f"{arm}/{form}"] = {key: value for key, value in categories.items() if value}

    contrasts = {}
    for first, base in (("B", "A"), ("C", "B")):
        for form in ("short", "explicit"):
            for mode, endpoint in (("reevaluate", "correct"), ("pair", "both_actions")):
                suffix = f"{form}/{mode}/{endpoint}"
                vector = vectors[f"{first}/{suffix}"] - vectors[f"{base}/{suffix}"]
                contrasts[f"{first}-{base}/{suffix}"] = {
                    "points": float(vector.mean() * 100),
                    "family_world95": interval(vector),
                    "wins": int((vector > 0).sum()),
                    "losses": int((vector < 0).sum()),
                }

    saved = read(root / "results/interleaved_112/statistical_result.json")
    for key, value in outcomes.items():
        reference = saved["primary_outcomes"][key]
        assert value["count"] == reference["count"] and np.allclose(value["family_world95"], reference["family_world95"])
    for key, value in paired.items():
        reference = saved["paired"][key]
        assert value["count"] == reference["count"] and np.allclose(value["family_world95"], reference["family_world95"])
    assert joint == saved["joint"]
    for key, value in contrasts.items():
        reference = saved["contrasts"][key]
        assert np.isclose(value["points"], reference["points"])
        assert np.allclose(value["family_world95"], reference["family_world95"])
        assert value["wins"] == reference["wins"] and value["losses"] == reference["losses"]
    return {
        "status": "PASS",
        "numpy": np.__version__,
        "bootstrap": {"draws": 10000, "seed": 2601026, "unit": "families then worlds, paired indices"},
        "primary_outcomes": outcomes,
        "paired": paired,
        "joint": joint,
        "contrasts": contrasts,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("artifact", nargs="?", type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    report = recompute(args.artifact.resolve())
    output = args.artifact.resolve() / "results/INTERLEAVED_STATISTICS_RECOMPUTED.json"
    output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"status": report["status"], "numpy": report["numpy"], "draws": 10000}, indent=2))
