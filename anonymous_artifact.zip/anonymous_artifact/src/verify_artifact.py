"""Offline verifier for the current anonymous WWW 2027 TRI artifact.

The verifier uses saved model text, ID maps, tool traces, receipts and logical
states. It performs no network, model, GPU or native-service calls.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from collections import Counter, defaultdict
from copy import deepcopy
from datetime import date, timedelta
from pathlib import Path


def read(path: Path):
    return json.loads(path.read_text())


def rows(path: Path):
    return [json.loads(line) for line in path.read_text().splitlines() if line]


def canonical(state):
    return sorted(state, key=lambda row: row["id"])


def winner(world, state):
    app = world["app"]
    valid = [
        row
        for row in state
        if (
            row.get("active", True)
            if app == "calendar"
            else not row.get("done", False)
            if app == "todoist"
            else not row.get("deleted", False) and "tri-w1" in row["tags"]
        )
    ]

    def value(row):
        if world["selector_field"] == "tag_count":
            return len(row["tags"])
        raw = row[world["selector_field"]]
        if world["selector_value_kind"] == "length":
            return len(raw)
        if world["selector_value_kind"] == "text":
            return str(raw).casefold()
        return raw

    values = [value(row) for row in valid]
    best = min(values) if world["selector_direction"] == "min" else max(values)
    selected = [row["id"] for row in valid if value(row) == best]
    assert len(selected) == 1
    return selected[0]


def apply_action(world, target):
    state = deepcopy(world["s1"])
    entity = next(row for row in state if row["id"] == target)
    action = world["action"]
    if action == "delete":
        state.remove(entity)
    elif action == "mark_complete":
        entity["done"] = True
    elif action == "postpone_one_day":
        entity["due_date"] = (date.fromisoformat(entity["due_date"]) + timedelta(days=1)).isoformat()
    elif action == "append_reviewed":
        entity["content"] += "\nreviewed"
    elif action == "prepend_reviewed":
        entity["content"] = "reviewed\n" + entity["content"]
    else:
        raise ValueError(action)
    return canonical(state)


def parse_target(raw):
    try:
        value = json.loads(raw)
        if not isinstance(value, dict) or value.get("decision") not in ("act", "resolve", "reject", "noop"):
            return None
        if value["decision"] in ("act", "resolve"):
            if not isinstance(value.get("target"), str) or not value["target"].strip():
                return None
            value["target"] = value["target"].strip()
        return value
    except (ValueError, TypeError, KeyError):
        return None


def parse_native(raw, stage="final"):
    try:
        value = json.loads(raw)
        if not isinstance(value, dict) or set(value) != {"decision", "target_id"}:
            return None
        allowed = ("bind", "defer", "clarify") if stage == "initial" else ("act", "clarify")
        if value["decision"] not in allowed:
            return None
        if value["decision"] in ("bind", "act"):
            if not isinstance(value["target_id"], str) or not value["target_id"].strip():
                return None
            value["target_id"] = value["target_id"].strip()
        elif value["target_id"] is not None:
            return None
        return value
    except (ValueError, TypeError, KeyError):
        return None


def verify_manifest(root: Path):
    manifest = root / "MANIFEST.sha256"
    if not manifest.exists():
        return {"checked": 0, "status": "SKIPPED_NO_MANIFEST"}
    checked = 0
    for line in manifest.read_text().splitlines():
        digest, rel = line.split("  ", 1)
        assert hashlib.sha256((root / rel).read_bytes()).hexdigest() == digest, rel
        checked += 1
    return {"checked": checked, "status": "PASS"}


def verify_target_choice(root: Path):
    records = rows(root / "results/target_choice/sessions.jsonl")
    assert len(records) == 6000
    grouped = defaultdict(dict)
    stable = defaultdict(dict)
    for row in records:
        parsed = parse_target(row["raw"])
        selected = parsed.get("target") if parsed and parsed["decision"] in ("act", "resolve") else None
        assert selected == row["selected"]
        assert (selected == row["gold"]) == row["correct"]
        target = grouped if row["transition"] == "flip" else stable
        target[row["model"], row["world"]][row["mode"]] = row
    counts = defaultdict(Counter)
    for (model, _world), pair in grouped.items():
        assert set(pair) == {"preserve", "reevaluate"}
        preserve, reevaluate = pair["preserve"], pair["reevaluate"]
        old, new = preserve["old"], preserve["new"]
        pattern = {
            (old, new): "both_correct",
            (old, old): "earlier_twice",
            (new, new): "updated_twice",
            (new, old): "reversed",
        }.get((preserve["selected"], reevaluate["selected"]), "other")
        counts[model].update(
            worlds=1,
            preserve=int(preserve["correct"]),
            reevaluate=int(reevaluate["correct"]),
            both=int(preserve["correct"] and reevaluate["correct"]),
        )
        counts[model][pattern] += 1
    expected = {
        "GPT": (202, 274, 182, 19, 92, 5, 2),
        "Gemini": (239, 281, 222, 13, 50, 1, 14),
        "Qwen27B": (66, 249, 25, 41, 223, 10, 1),
        "Llama": (71, 225, 12, 59, 210, 4, 15),
    }
    for model, values in expected.items():
        observed = counts[model]
        assert observed["worlds"] == 300
        assert tuple(observed[key] for key in ("preserve", "reevaluate", "both", "earlier_twice", "updated_twice", "reversed", "other")) == values
    stable_pairs = Counter()
    for (model, _world), pair in stable.items():
        if model in expected:
            stable_pairs[model] += int(pair["preserve"]["correct"] and pair["reevaluate"]["correct"])
    assert tuple(stable_pairs[model] for model in expected) == (294, 292, 278, 258)
    return {"rows": 6000, "changed_worlds_per_configuration": 300, "counts": {k: dict(v) for k, v in counts.items()}, "unchanged_both": dict(stable_pairs)}


def verify_fixed_wording_30(root: Path):
    records = rows(root / "results/fixed_wording_30/sessions.jsonl")
    assert len(records) == 180
    grouped = defaultdict(dict)
    for row in records:
        parsed = parse_target(row["raw_decision"])
        correct = bool(parsed and parsed["decision"] in ("act", "resolve") and parsed.get("target") == row["gold"] and row["finish_reason"] != "length")
        assert correct == row["correct"]
        assert (parsed.get("target") if parsed else None) == row["target"]
        grouped[row["cluster_id"], row["mode"]][row["formulation"]] = row
    assert len(grouped) == 60
    changed = {row["cluster_id"] for row in records if row["transition"] == "flip"}
    assert len(changed) == 24
    both = {}
    for formulation in ("original", "chronological", "state_relative"):
        both[formulation] = sum(all(grouped[cluster, mode][formulation]["correct"] for mode in ("preserve", "reevaluate")) for cluster in changed)
    assert both == {"original": 5, "chronological": 23, "state_relative": 23}
    for cluster in changed:
        assert len({grouped[cluster, "reevaluate"][formulation]["target"] for formulation in both}) == 1
    return {"rows": len(records), "changed_worlds": len(changed), "both_correct": both}


def verify_order_check_30(root: Path):
    directory = root / "results/order_check_30"
    responses = rows(directory / "responses.jsonl")
    decisions = rows(directory / "decisions.jsonl")
    pairs_data = rows(directory / "pairs.jsonl")
    summary = read(directory / "summary.json")
    assert len(responses) == len(decisions) == 240 and len(pairs_data) == 120
    response_by_id = {row["id"]: row for row in responses}
    assert Counter(row["status"] for row in responses) == {"valid": 239, "technical_failure": 1}
    for decision in decisions:
        response = response_by_id[decision["id"]]
        if response["status"] == "technical_failure":
            assert decision["status"] == "technical_failure" and decision["target"] is None
        else:
            parsed = parse_target(response["content"])
            assert parsed and parsed.get("target") == decision["target"]
    panels = defaultdict(Counter)
    for pair in pairs_data:
        key = pair["transition"], pair["order"]
        panels[key].update(worlds=1, both=int(pair["both"]))
        panels[key][pair["pattern"]] += 1
    assert tuple(panels["flip", "after_before"][key] for key in ("worlds", "both", "always_new")) == (30, 0, 25)
    assert tuple(panels["flip", "before_after"][key] for key in ("worlds", "both", "always_new")) == (30, 8, 17)
    assert summary["paired_changed"]["joint"] == {"00": 22, "01": 8}
    assert summary["paired_changed"]["exact_discordance_p"] == 0.0078125
    return {"assigned": 240, "responses": 239, "changed_both": {"after_before": 0, "before_after": 8}, "unchanged_both_each": 27}


def verify_native_504(root: Path):
    worlds = {world["cluster_id"]: world for world in rows(root / "data/native_504/worlds.jsonl")}
    sessions = rows(root / "results/native_504/sessions.jsonl")
    assert len(sessions) == 3240 and len(worlds) == 540
    results = defaultdict(Counter)
    pairs = defaultdict(list)
    for session in sessions:
        case = session["case"]
        world = worlds[case["cluster_id"]]
        model = session["model"]
        old, new = winner(world, world["s0"]), winner(world, world["s1"])
        assert world["gold"] == {"preserve": old, "reevaluate": new}
        if case["kind"] == "selector_probe":
            decision = parse_native(session["calls"][0]["raw"])
            reverse = {str(value): key for key, value in session["ids_after"].items()}
            selected = reverse.get(decision["target_id"]) if decision else None
            assert selected == session["selected_probe"]
            results[model].update(probes=1, probe_correct=int(selected == new))
            continue
        first = parse_native(session["calls"][0]["raw"], "initial")
        bound = {str(value): key for key, value in session["ids_initial"].items()}.get(first["target_id"]) if first else None
        assert first == session["first"] and bound == session["bound"]
        final = parse_native(session["calls"][1]["raw"]) if len(session["calls"]) > 1 else None
        target = {str(value): key for key, value in (session["ids_after"] or {}).items()}.get(final["target_id"]) if final else None
        assert final == session["final"] and target == session["action_target"]
        acted = session["receipt"] is not None
        if acted:
            assert session["receipt"]["logical_id"] == target
            assert canonical(session["final_state"]) == apply_action(world, target)
        else:
            expected_state = world["s1"] if session["refreshed"] else world["s0"]
            assert canonical(session["final_state"]) == canonical(expected_state)
        initial_ok = bool(first and ((first["decision"] == "bind" and bound == old) if case["mode"] == "preserve" else first["decision"] == "defer"))
        correct = bool(acted and target == world["gold"][case["mode"]])
        exact = bool(acted and canonical(session["final_state"]) == apply_action(world, world["gold"][case["mode"]]))
        eligible = bool(case["mode"] == "preserve" and initial_ok and session["refreshed"] and world["winner_change"])
        computed = {
            "initial_compliance": initial_ok,
            "correct_action": correct,
            "exact_final": exact,
            "strict": initial_ok and correct and exact,
            "wrong_write": acted and not correct,
            "no_action": not acted,
            "conditional_preserve_eligible": eligible,
            "post_binding_substitution": eligible and acted and target != old,
        }
        assert all(value == session["score"][key] for key, value in computed.items()), case["session_id"]
        if world["winner_change"]:
            results[model].update(
                executions=1,
                correct_action=correct,
                wrong_write=computed["wrong_write"],
                no_action=computed["no_action"],
                eligible=eligible,
                substitution=computed["post_binding_substitution"],
            )
            pairs[model, world["cluster_id"]].append(correct)
    for key, values in pairs.items():
        assert len(values) == 2
        results[key[0]]["both"] += int(all(values))
    assert tuple(results["qwen"][key] for key in ("both", "correct_action", "wrong_write", "no_action", "eligible", "substitution")) == (487, 991, 17, 0, 487, 0)
    assert tuple(results["glm"][key] for key in ("both", "correct_action", "wrong_write", "no_action", "eligible", "substitution")) == (468, 972, 16, 20, 484, 0)
    with (root / "results/native_504/world_pairs.csv").open() as handle:
        table = [row for row in csv.DictReader(handle) if row["included_in_main_504"] == "1"]
    assert len(table) == 1008
    for row in table:
        model = {"Qwen3.5-397B-A17B": "qwen", "GLM-5.2": "glm"}[row["model"]]
        values = pairs[model, row["source_cluster_id"]]
        assert int(row["paired_action_success"]) == int(all(values))
    return {"sessions": len(sessions), "worlds": len(worlds), "counts": {key: dict(value) for key, value in results.items()}}


def verify_fixed_tool_sessions(root: Path, receipt: str):
    worlds = {world["cluster_id"]: world for world in read(root / "data/original_112/worlds.json")}
    sessions = rows(root / f"results/original_112/receipt_{receipt}_sessions.jsonl")
    assert len(sessions) == 1120
    counts = defaultdict(Counter)
    pairs = defaultdict(dict)
    for entry in sessions:
        case = entry["case"]
        world = worlds[case["fixture_id"]]
        result = entry["result"]
        key = (case["model"], "changed" if world["winner_change"] else "unchanged", case["clarity"], case["mode"])
        counts[key]["assigned"] += 1
        calls = {call["step"]: call for call in entry["calls"]}
        for call in calls.values():
            request = call["requested"]
            assert request["temperature"] == 0 and request["top_p"] == 1
            assert request["max_completion_tokens"] == 4096 and request["enable_thinking"] is False
        for event in result.get("trace", []):
            command = json.loads(calls[event["step"]]["raw"])
            assert command == {"tool": event["tool"], "arguments": event["arguments"]}
            assert event["tool"] == ("list_entities", "record_choice", "synchronize", "perform_action")[event["step"]]
        if not calls:
            assert result["unavailable"] and result["error"] and not result["trace"]
            correct = wrong = strict = initial = False
            counts[key]["no_action"] += 1
            pairs[case["model"], world["base_id"], world["winner_change"], case["clarity"]][case["mode"]] = (correct, strict)
            continue
        synced = any(event["tool"] == "synchronize" for event in result["trace"])
        ids = entry["ids_after"] if synced and entry["ids_after"] else entry["ids_initial"]
        reverse = {str(value): key for key, value in ids.items()}
        actions = [event for event in result["trace"] if event["tool"] == "perform_action" and event.get("attempted") and event["receipt"].get("status") == "ok"]
        accepted = bool(actions)
        target = reverse.get(str(actions[-1]["arguments"]["entity_id"])) if actions else None
        gold = world["gold"][case["mode"]]
        if accepted:
            assert entry["receipt"]["logical_id"] == target == result["action_id"]
            assert canonical(entry["final_state"]) == apply_action(world, target)
        elif entry["final_state"] is not None:
            assert canonical(entry["final_state"]) == canonical(world["s1"] if synced else world["s0"])
        choices = [event for event in result["trace"] if event["tool"] == "record_choice"]
        prefix = None
        if choices:
            args = choices[0]["arguments"]
            prefix = {"decision": args["decision"], "entity_id": {str(value): key for key, value in entry["ids_initial"].items()}.get(str(args["entity_id"]))}
        initial = prefix == ({"decision": "select", "entity_id": world["old_target_id"]} if case["mode"] == "preserve" else {"decision": "defer", "entity_id": None})
        correct = bool(accepted and target == gold)
        wrong = bool(accepted and target != gold)
        strict = bool(initial and synced and correct and result["error"] is None)
        assert result["prefix"] == prefix
        assert result["prefix_correct"] == initial
        assert result["wrong_entity_write"] == wrong
        assert result["strict_success"] == strict
        counts[key]["correct_action" if correct else "wrong_write" if wrong else "no_action"] += 1
        counts[key]["strict"] += int(strict)
        counts[key]["initial"] += int(initial)
        counts[key]["technical_failure"] += int(bool(result["unavailable"]))
        pairs[case["model"], world["base_id"], world["winner_change"], case["clarity"]][case["mode"]] = (correct, strict)
    pair_counts = Counter()
    for (model, _world, changed, clarity), pair in pairs.items():
        assert set(pair) == {"preserve", "reevaluate"}
        pair_counts[model, changed, clarity, "both_actions"] += int(pair["preserve"][0] and pair["reevaluate"][0])
        pair_counts[model, changed, clarity, "both_strict"] += int(pair["preserve"][1] and pair["reevaluate"][1])
    return {"sessions": len(sessions), "counts": {"/".join(map(str, key)): dict(value) for key, value in counts.items()}, "pairs": {"/".join(map(str, key)): value for key, value in pair_counts.items()}}


def verify_original_112(root: Path):
    a = verify_fixed_tool_sessions(root, "A")
    b = verify_fixed_tool_sessions(root, "B")
    expected_actions = {
        "A": {
            "qwen/changed/short/preserve": (12, 88, 12),
            "qwen/changed/explicit/preserve": (109, 1, 2),
            "qwen/changed/short/reevaluate": (62, 11, 39),
            "qwen/changed/explicit/reevaluate": (2, 0, 110),
            "glm/changed/short/preserve": (37, 30, 45),
            "glm/changed/explicit/preserve": (78, 1, 33),
            "glm/changed/short/reevaluate": (5, 0, 107),
            "glm/changed/explicit/reevaluate": (2, 0, 110),
        },
        "B": {
            "qwen/changed/short/preserve": (20, 74, 18),
            "qwen/changed/explicit/preserve": (106, 1, 5),
            "qwen/changed/short/reevaluate": (62, 15, 35),
            "qwen/changed/explicit/reevaluate": (86, 19, 7),
            "glm/changed/short/preserve": (26, 31, 55),
            "glm/changed/explicit/preserve": (66, 1, 45),
            "glm/changed/short/reevaluate": (18, 0, 94),
            "glm/changed/explicit/reevaluate": (4, 0, 108),
        },
    }
    for receipt, report in (("A", a), ("B", b)):
        for key, expected in expected_actions[receipt].items():
            observed = report["counts"][key]
            assert tuple(observed.get(name, 0) for name in ("correct_action", "wrong_write", "no_action")) == expected
    expected_pairs = {
        "A": (2, 2, 2, 1),
        "B": (8, 83, 9, 2),
    }
    for receipt, report in (("A", a), ("B", b)):
        observed = tuple(
            report["pairs"][key]
            for key in (
                "qwen/True/short/both_actions",
                "qwen/True/explicit/both_actions",
                "glm/True/short/both_actions",
                "glm/True/explicit/both_actions",
            )
        )
        assert observed == expected_pairs[receipt]
    return {"receipt_A": a, "receipt_B": b}


def verify_interleaved(root: Path):
    worlds = {world["cluster_id"]: world for world in read(root / "data/interleaved_112/worlds.json")}
    sessions = rows(root / "results/interleaved_112/sessions.jsonl")
    assert len(sessions) == 1680 and len(worlds) == 140
    counts = defaultdict(Counter)
    pairs = defaultdict(dict)
    eligible_wrong = Counter()
    eligible_total = Counter()
    for entry in sessions:
        case = entry["case"]
        result = entry["result"]
        score = entry["score"]
        world = worlds[case["fixture_id"]]
        assert winner(world, world["s0"]) == world["old_target_id"]
        assert winner(world, world["s1"]) == world["new_target_id"]
        calls = {call["step"]: call for call in entry["calls"]}
        for call in calls.values():
            request = call["requested"]
            assert request["model"] == "qwen3.5-397b-a17b"
            assert request["temperature"] == 0 and request["top_p"] == 1
            assert request["max_completion_tokens"] == 4096 and request["enable_thinking"] is False
        synchronized = False
        prefix = None
        accepted = False
        action = None
        for index, event in enumerate(result["trace"]):
            assert event["step"] == index
            command = json.loads(calls[index]["raw"])
            assert command == {"tool": event["tool"], "arguments": event["arguments"]}
            assert bool(event["synchronized_before"]) == synchronized
            if case["arm"] != "C":
                assert event["tool"] == ("list_entities", "record_choice", "synchronize", "perform_action")[index]
            if event["tool"] in ("list_entities", "synchronize"):
                if event["tool"] == "synchronize":
                    assert not synchronized
                    synchronized = True
                mapping = entry["ids_after"] if synchronized else entry["ids_initial"]
                reverse = {str(value): key for key, value in mapping.items()}
                observed = [
                    {"id": reverse[str(entity["persistent_id"])], **{key: value for key, value in entity.items() if key != "persistent_id"}}
                    for entity in event["receipt"]["entities"]
                ]
                assert canonical(observed) == canonical(world["s1"] if synchronized else world["s0"])
            elif event["tool"] == "record_choice":
                if not synchronized and prefix is None:
                    reverse = {str(value): key for key, value in entry["ids_initial"].items()}
                    prefix = {"decision": event["arguments"]["decision"], "entity_id": reverse.get(str(event["arguments"]["entity_id"]))}
                expected = {"recorded": event["arguments"]}
                if case["arm"] in ("B", "C"):
                    expected["execution_note"] = "Decision recorded; no entity has been modified. After synchronization, call perform_action to carry out the requested modification."
                assert event["receipt"] == expected
            else:
                assert event["tool"] == "perform_action" and synchronized and index == len(result["trace"]) - 1
                accepted = event["receipt"]["status"] == "ok"
                if accepted:
                    reverse = {str(value): key for key, value in entry["ids_after"].items()}
                    action = reverse[str(event["arguments"]["entity_id"])]
                    assert entry["receipt"]["logical_id"] == action
        if accepted:
            assert canonical(entry["final_state"]) == apply_action(world, action)
        elif entry["final_state"] is not None:
            assert canonical(entry["final_state"]) == canonical(world["s1"] if synchronized else world["s0"])
        initial = prefix == ({"decision": "select", "entity_id": world["old_target_id"]} if case["mode"] == "preserve" else {"decision": "defer", "entity_id": None})
        correct = bool(accepted and synchronized and action == world["gold"][case["mode"]] and canonical(entry["final_state"]) == apply_action(world, world["gold"][case["mode"]]))
        wrong = bool(accepted and action != world["gold"][case["mode"]])
        strict = bool(initial and correct and result["error"] is None)
        assert result["prefix"] == prefix and result["action_id"] == action
        assert result["initial_correct"] == initial and result["correct_action"] == correct
        assert result["wrong_write"] == wrong and result["strict_success"] == strict
        assert int(correct) == score["correct"] and int(wrong) == score["wrong"]
        assert int(not accepted) == score["no_action"] and int(strict) == score["strict"] and int(initial) == score["initial"]
        key = (case["arm"], case["clarity"], "changed" if world["winner_change"] else "unchanged", case["mode"])
        counts[key].update(assigned=1, correct=int(correct), wrong=int(wrong), no_action=int(not accepted), strict=int(strict), initial=int(initial), unavailable=int(bool(result["unavailable"])))
        pair_key = (case["arm"], case["clarity"], world["winner_change"], world["base_id"])
        pairs[pair_key][case["mode"]] = {"correct": correct, "strict": strict, "action": action, "old": world["old_target_id"], "new": world["new_target_id"]}
        if world["winner_change"] and case["mode"] == "preserve" and initial and synchronized:
            eligible_total[case["arm"], case["clarity"]] += 1
            eligible_wrong[case["arm"], case["clarity"]] += int(wrong)
    paired = Counter()
    joint = defaultdict(Counter)
    for (arm, clarity, changed, _world), pair in pairs.items():
        assert set(pair) == {"preserve", "reevaluate"}
        p, r = pair["preserve"], pair["reevaluate"]
        paired[arm, clarity, changed, "both"] += int(p["correct"] and r["correct"])
        paired[arm, clarity, changed, "strict"] += int(p["strict"] and r["strict"])
        if changed:
            category = "missing_action" if p["action"] is None or r["action"] is None else {
                (p["old"], p["new"]): "both_correct",
                (p["old"], p["old"]): "earlier_twice",
                (p["new"], p["new"]): "updated_twice",
                (p["new"], p["old"]): "reversed",
            }.get((p["action"], r["action"]), "other_complete")
            joint[arm, clarity][category] += 1
    expected = {
        ("A", "short"): ((19, 73, 20), (67, 6, 39), 12, 0),
        ("A", "explicit"): ((106, 5, 1), (1, 1, 110), 1, 1),
        ("B", "short"): ((30, 68, 14), (66, 11, 35), 18, 0),
        ("B", "explicit"): ((104, 4, 4), (94, 14, 4), 88, 88),
        ("C", "short"): ((5, 90, 17), (107, 5, 0), 3, 0),
        ("C", "explicit"): ((87, 4, 21), (96, 15, 1), 73, 46),
    }
    for key, (p_expected, r_expected, both_expected, strict_expected) in expected.items():
        p = counts[key + ("changed", "preserve")]
        r = counts[key + ("changed", "reevaluate")]
        assert tuple(p[name] for name in ("correct", "wrong", "no_action")) == p_expected
        assert tuple(r[name] for name in ("correct", "wrong", "no_action")) == r_expected
        assert paired[key + (True, "both")] == both_expected
        assert paired[key + (True, "strict")] == strict_expected
    expected_joint = {
        ("A", "short"): (12, 6, 49, 0, 0, 45),
        ("B", "short"): (18, 10, 48, 0, 1, 35),
        ("C", "short"): (3, 2, 87, 2, 1, 17),
        ("A", "explicit"): (1, 1, 0, 0, 0, 110),
        ("B", "explicit"): (88, 12, 0, 0, 4, 8),
        ("C", "explicit"): (73, 12, 1, 0, 4, 22),
    }
    categories = ("both_correct", "earlier_twice", "updated_twice", "reversed", "other_complete", "missing_action")
    for key, values in expected_joint.items():
        assert tuple(joint[key][name] for name in categories) == values
    assert (eligible_wrong["A", "short"], eligible_total["A", "short"]) == (71, 106)
    assert (eligible_wrong["B", "short"], eligible_total["B", "short"]) == (66, 108)
    controls_expected = {
        ("A", "short"): (50, 3, 3, 23, 0),
        ("A", "explicit"): (28, 0, 28, 2, 2),
        ("B", "short"): (50, 3, 3, 23, 0),
        ("B", "explicit"): (54, 2, 0, 26, 26),
        ("C", "short"): (54, 0, 2, 26, 0),
        ("C", "explicit"): (47, 0, 9, 19, 14),
    }
    for key, values in controls_expected.items():
        p = counts[key + ("unchanged", "preserve")]
        r = counts[key + ("unchanged", "reevaluate")]
        combined = (p["correct"] + r["correct"], p["wrong"] + r["wrong"], p["no_action"] + r["no_action"], paired[key + (False, "both")], paired[key + (False, "strict")])
        assert combined == values
    return {
        "sessions": len(sessions),
        "groups": {"/".join(map(str, key)): dict(value) for key, value in counts.items()},
        "paired": {"/".join(map(str, key)): value for key, value in paired.items()},
        "joint": {"/".join(key): dict(value) for key, value in joint.items()},
        "post_binding_short": {"A": "71/106", "B": "66/108"},
    }


def verify(root: Path):
    report = {
        "status": "PASS",
        "scope": "Offline re-scoring from saved outputs and states; no model or native-service calls.",
        "manifest": verify_manifest(root),
        "target_choice_300": verify_target_choice(root),
        "fixed_wording_30": verify_fixed_wording_30(root),
        "order_check_30": verify_order_check_30(root),
        "native_504": verify_native_504(root),
        "original_112": verify_original_112(root),
        "interleaved_112": verify_interleaved(root),
    }
    output = root / "results/OFFLINE_VERIFICATION.json"
    output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("artifact", nargs="?", type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    result = verify(args.artifact.resolve())
    print(json.dumps({"status": result["status"], "manifest": result["manifest"], "verified": ["target_choice_300", "fixed_wording_30", "order_check_30", "native_504", "original_112", "interleaved_112"]}, indent=2))
