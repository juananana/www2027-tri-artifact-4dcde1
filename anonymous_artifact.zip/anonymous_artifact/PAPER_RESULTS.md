# Paper results and reproduction map

The result inventory was frozen from the current WWW 2027 submission manuscript. The manuscript source and PDF are not distributed in this artifact. The labels below follow that manuscript's item numbering at package freeze. A result is marked **offline verified** only when the distributed per-instance material and scorer reproduced it in this package.

## Metric distinctions

- **Target correctness:** the selected logical entity ID equals the timing-specific gold target for one request.
- **Contrast consistency / both correct:** target correctness holds for Preserve and Reevaluate on the same changed world.
- **Paired action success:** both requests execute successful actions on their correct entities.
- **Strict paired action success:** paired action success plus an observable correct initial Preserve binding or Reevaluate deferral and exact captured final state. Under arm C, a correct action without a pre-refresh record is action-successful but not strict.
- **Wrong write:** an admitted action successfully changes a non-gold entity.
- **No action:** no successful entity-changing action, including protocol/format/connection failures.

## Main-text map

| Paper item | Population | Distributed source | Offline command/check | Status and reproduced result |
| --- | --- | --- | --- | --- |
| Figure 1 | One retained Calendar example | Task definitions in `data/target_choice/` | Conceptual figure; no empirical score | Paper figure not bundled; underlying task records retained |
| Figure 2 | Original A/B four-call protocol | `docs/protocols/` | Protocol inspection; per-session reconstruction below | Paper figure not bundled; protocol records retained |
| Figure 3 and Sec. 5.1 | 300 changed target-choice worlds per configuration | `data/target_choice/`; `results/target_choice/sessions.jsonl` | `src/verify_artifact.py` | **Offline verified.** Qwen27B: Preserve 66/300, Reevaluate 249/300, both 25/300, updated target twice 223/300. GPT/Gemini/Llama both: 182/222/12. Related unchanged pairs: 294/292/278/258 for GPT/Gemini/Qwen27B/Llama. |
| Fixed-configuration wording claim in Sec. 5.1 | 24 changed worlds, three formulations, Qwen397B | `data/fixed_wording_30/`; `results/fixed_wording_30/sessions.jsonl` | `src/verify_artifact.py` | **Offline verified.** Both correct: original 5/24, chronological 23/24, state-relative 23/24. |
| Snapshot-order claim in Sec. 5.1 | 30 changed + 30 unchanged worlds in two orders, Qwen27B | `results/order_check_30/`; protocol in `docs/protocols/` | `src/verify_artifact.py` | **Offline verified.** Changed both correct 0/30 vs 8/30; unchanged 27/30 in each order; 239 responses and one retained connection failure. |
| Table 1 and Figure 4 | 504 changed guided-native worlds per configuration | `data/native_504/`; `results/native_504/sessions.jsonl` and `world_pairs.csv` | `src/verify_artifact.py` | **Offline verified.** Qwen397B paired action 487/504; GLM-5.2 468/504. Correct/wrong/no-action executions: 991/17/0 and 972/16/20 of 1,008. Conditional substitutions: 0/487 and 0/484. |
| Post-binding audit in Sec. 5.3 | Qualified short Preserve trajectories in new-seed panel | `results/interleaved_112/sessions.jsonl` | `src/verify_artifact.py` | **Offline verified.** Wrong writes after correct initial binding and completed refresh: A 71/106; B 66/108. |
| Exploratory original A/B comparison | Original 112 changed worlds plus 28 related controls, Qwen397B and GLM-5.2 | `data/original_112/worlds.json`; `results/original_112/receipt_A_sessions.jsonl`, `receipt_B_sessions.jsonl` | `src/verify_artifact.py` | **Offline verified.** Qwen explicit Reevaluate A 2/0/110 and B 86/19/7 correct/wrong/no-action; both actions 2/112 to 83/112. GLM explicit Preserve A 78/1/33 and B 66/1/45. |
| Table 2 | New-seed interleaved Qwen397B panel: 112 changed worlds per arm/text row | `data/interleaved_112/`; `results/interleaved_112/sessions.jsonl` | Both scripts in `src/` | **Offline verified.** A short: P 19/73/20, R 67/6/39, both/strict 12/0. A explicit: 106/5/1, 1/1/110, 1/1. B short: 30/68/14, 66/11/35, 18/0. B explicit: 104/4/4, 94/14/4, 88/88. C short: 5/90/17, 107/5/0, 3/0. C explicit: 87/4/21, 96/15/1, 73/46. |
| Figure 5 | Joint action identities for Table 2 | Same interleaved files | `src/verify_artifact.py` | **Offline verified.** A-short 12/6/49/0/0/45; B-short 18/10/48/0/1/35; C-short 3/2/87/2/1/17; A-explicit 1/1/0/0/0/110; B-explicit 88/12/0/0/4/8; C-explicit 73/12/1/0/4/22 for both-correct/earlier-twice/updated-twice/reversed/other-complete/missing-action. |
| Figure 6 | One original-A Qwen397B short Preserve wrong write | `results/original_112/receipt_A_sessions.jsonl` | Trace/state checks in `src/verify_artifact.py` | **Offline verified as part of the 1,120-session A reconstruction.** The paper figure is not bundled and aliases IDs for display only. |

## Related unchanged controls

These controls remain separate from changed-world denominators.

- Guided native 36-world controls: changed/unchanged paired action is 34/36 vs 35/36 for Qwen397B and 32/36 vs 35/36 for GLM-5.2. The per-instance native records are distributed and state-verified.
- New-seed 28-world interleaved controls: A-short 50/3/3 executions, both/strict 23/0; A-explicit 28/0/28, 2/2; B-short 50/3/3, 23/0; B-explicit 54/2/0, 26/26; C-short 54/0/2, 26/0; C-explicit 47/0/9, 19/14. These are **offline verified** from 56 sessions per row.
- Original A/B related controls are retained in both 1,120-session exports and checked by the same scorer.

## Interleaved statistical and recovery checks

`src/recompute_interleaved_statistics.py` reproduces the 10,000-draw family-then-world paired bootstrap with seed 2601026. It matches the saved primary outcomes, paired intervals, joint identities and planned contrasts. The main point results include explicit B–A paired actions +77.7 percentage points with interval [57.1, 93.8], B–A short +5.4 [−4.5, 15.2], C–B explicit −13.4 [−24.1, −2.7], and C–B short −13.4 [−22.3, −4.5].

The artifact retains all 1,680 assignments and all 32 connection failures. Deterministic missing-transport bounds and post-hoc stage localization are in `results/interleaved_112/completeness_result.json` and the paper appendix. Recovery changed concurrency and failure monitoring; this panel is not presented as an uninterrupted execution of the original freeze.

## Appendix and report-only coverage

- Claude strict/normalized formatting results, Qwen thinking, the 60-world cross-run wording table, shared-prefix representation, candidate-count sensitivity, and smaller interface/timing panels are retained in `results/secondary_report_only/`. They are **report-level coverage** in this compact package unless separately listed above; they are not labeled independently re-scored here.
- The public aggregate reader result and workflow are in `docs/human_review_aggregate.json` and `docs/human_evaluation_workflow.md`. Individual private returns are intentionally excluded, so the reader result is **aggregate-only and not independently re-scorable** from the release.
- Manuscript TeX/PDF, bibliography, paper figures and generated table fragments are intentionally outside this artifact. `PAPER_RESULTS.md` preserves only the mapping from manuscript item labels to distributed row-level evidence and scorers.

No mismatch was found for any item marked offline verified. A future mismatch must be reported as a discrepancy; the data must not be modified to make it agree with the manuscript.
