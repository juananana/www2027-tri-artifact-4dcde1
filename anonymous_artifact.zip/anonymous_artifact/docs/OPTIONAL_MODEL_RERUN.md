# Optional external rerun

Offline verification is the supported reviewer path. A fresh model run is optional and was not performed during packaging.

## Preconditions

1. Obtain the upstream AppWorld/OpenApps environments under their original licenses and recreate isolated service databases.
2. Use the versions in `configs/requirements-rerun.txt` and the protocol/model settings in `configs/model_protocols.json`.
3. Supply provider credentials through environment variables, never by editing a tracked configuration. The retained author runner expects a DashScope-compatible credential such as `DASHSCOPE_API_KEY`; no credential is included here.
4. Use a new output directory. Do not overwrite the distributed results.

## Required gate sequence

1. Run the zero-model task/selector/action checks.
2. Run a bounded native-service smoke test including a correct path, wrong-target path, malformed output and connection failure.
3. Freeze model identifier, endpoint, messages, temperature, top-p, completion cap, seed where supported, retry policy and stopping rule.
4. Run a separate technical pilot. Do not tune on semantic outcomes.
5. Preserve every assignment, failure and raw response; do not retry semantic failures or failed requests solely to improve the result.

The files under `src/reference/` document the author-side preparation, controller, runner and audit implementations. They retain repository-relative dependencies and are not advertised as a standalone one-command rerun. A reviewer should treat a fresh hosted execution as a new replication: provider aliases and weights are not pinned, and the original interleaved run required disclosed recovery amendments.
