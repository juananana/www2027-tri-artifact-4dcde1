# Public task audit rules

2026-10-23. Scope: local AppWorld data 0.1.0 train/dev, 147 instructions in 49 three-variant scenario families. No test split. This is an AI-assisted author audit, not independent human annotation. The auditor has already seen the inventory and prior results; these rules precede this round's aggregation, not first exposure. No claim of prospective/blind classification.

## Unit and fields

One ledger row per task, retaining exact instruction, relative source, source hash, data version, family and split. A manually reviewed family rule describes the common function; each variant remains separately traceable. Family-level aggregation uses the ID prefix, not linguistic similarity; all three instructions must be checked before sharing a rule. Counts describe this released subset, never user traffic.

Selection classes are mutually exclusive descriptions of the primary business selection: `rank_one` (one extremum, including historical latest), `rank_set` (top-k or one extremum per group), `filtered_set` (all matching records), `named` (identity specified by name/key/history), `aggregate` (count/sum over a selected population), `feasible_choice` (any satisfying object), `sequence` (traverse until condition), `current_pointer` (current object), `mixed` (named object and complementary set). A named container does not make a ranked song a named target. A date range alone is not a ranking. Secondary named/property/set structure is retained in the rationale rather than counted as independent tasks.

Side effects: `read_only`, `write`, `mixed_write`; these mean requested effects in simulated application records, not production service execution. `write` includes playback/follow/message/filesystem; business consequence is described separately. Writes to an output file do not imply mutation of the selected input entity.

Update opportunity: `candidate` is a plausible state intervention that might change a selected identity/set while retaining business function, not an observed legal API event. `not_for_identity` means the business target is historically or explicitly fixed; changing other facts does not license substituting that target. `answer_only` has no original entity action. Native API legality, uniqueness and action validity remain unverified unless a task-specific oracle exists.

Dual validity: `verified_prior_oracle` only for c901732_2 under the exact prior injected update; `unverified` otherwise; `not_applicable` for no original action or a fixed named target. No transfer of oracle qualification across siblings. Natural distinct timing: `author_extension_unvalidated`, `business_conflict`, or `not_applicable`. The original instruction's temporal phrases are retained separately; “currently”, “so far”, historical “last”, and execution order are NOT automatically a contract relative to an independently arriving update.

Source code presence (`evaluation.py`, `solution.py`) is not an execution pass. All candidate gates remain UNKNOWN until checked. Previous c901732_2 success establishes deterministic execution only, not model success, naturalness, or complete adapted scoring.

## GO gate

Require two different business functions with original IDs; unchanged action/function; independently executable legal update; changed/unchanged x before/after native oracle; clear timing meaning with independent confirmation when needed; exact target and permitted-side-effect checks; a predeclared question not answered by E25; time feasibility. Any missing critical gate prevents paid runs. Do not run new oracles merely to accumulate cases when semantic/information gates are already unmet.

## Verification

Validate exact train/dev ID coverage, 147 distinct rows, 49 families of three, all input hashes unchanged, category vocabulary, complete explanations and deterministic summary regeneration. A second pass by the same AI checks exceptions and category boundaries; this is not inter-rater agreement or independent human review. No percentages about deployment prevalence will be reported.
