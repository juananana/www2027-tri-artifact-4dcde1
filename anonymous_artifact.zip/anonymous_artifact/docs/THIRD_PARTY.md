# Third-party notices

The released worlds are author adaptations informed by public schemas and state semantics from AgentDojo, tau2-bench, ToolSandbox, AppWorld and OpenApps. They are not unmodified upstream tasks and are not official results of those projects.

This package does not bundle upstream runtimes, service databases or model weights. The corresponding upstream license texts are retained in `docs/third_party/` for attribution and review. Their presence does not apply a new license to author-owned material, and this package does not assert rights beyond the terms of each upstream license.

OpenApps carries an attribution/non-commercial license; accordingly, its runtime is not repackaged here. AppWorld and the other upstream projects must be obtained from their own sources under their own terms for any fresh native replay.
