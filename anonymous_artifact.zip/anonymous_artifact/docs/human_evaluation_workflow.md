# Stage-II independent language review workflow

The immutable input is
`runs/alibaba_factorial_20261021/HUMAN_REVIEW_ITEMS.json` (96 items). Two real,
non-author readers review the same package independently. Do not use an author or an LLM as a
substitute. Keep names and contact details outside the repository.

For every item, each reader records:

- `selection_time`: `before`, `after`, or `ambiguous`;
- `action_target_id`: one ID visible in the item, or `ambiguous`;
- `naturalness_1_to_5`: integer 1--5.

Create a blank response file with:

```bash
python3 -B human_review.py template /authorized/private/location/reviewer_1.json
```

Validate each completed file before comparing them:

```bash
python3 -B human_review.py validate /authorized/private/location/reviewer_1.json
```

After both independent submissions, generate the disagreement list. This first pass does not
expose either response to the other reader before submission:

```bash
python3 -B human_review.py summarize reviewer_1.json reviewer_2.json review_summary.json
```

If the status is `AWAITING_ADJUDICATION`, a third non-author reader supplies exactly the listed
items in the same schema. Then rerun with `--adjudication`. Commit only the anonymous summary and
provenance hashes if participant privacy requires raw files to remain outside the repository.

These judgments can establish whether readers recover the intended selection time/target and
whether short and explicit wording differ in perceived obligation. They do not make the two
wordings paraphrases by fiat, establish natural-traffic prevalence, or provide a model upper bound.

## 2026-10-21 return status

Two real, anonymous, independent reviewers completed the 96-item package. The user confirmed the
human provenance directly; misleading `AI-simulated annotation` text in the returned forms was an
anonymization label and does not describe the data source. The completed DOCX files remain outside
the repository. Repository records retain only hashes and anonymous aggregates.

The reviewers agree on all 96 selection-time judgments and all 96 target-ID judgments. They both
recover the intended selection time on all items and the intended target on 84 items. On the
remaining 12 items, both choose `ambiguous`; all 12 belong to the three Todoist
`highest_priority` fixtures, whose tables do not define whether larger or smaller numeric priority
values rank higher. Short and explicit forms receive the same semantic interpretation in all 48
matched pairs, but six pairs inherit this priority-scale ambiguity.

A third real, anonymous, independent non-author reader then completed the predeclared 18-item
naturalness adjudication without seeing A/B scores. All 18 responses are valid integers from 1 to
5. The adjudicated 96-item distribution is 30 scores of 3, 45 scores of 4, and 21 scores of 5
(mean 3.90625). Short instructions average 4.25; explicit instructions average 3.5625. In the 48
matched short/explicit comparisons, explicit is one point lower in 33 and tied in 15; it is never
higher. This is a wording-naturalness result, not a semantic or model-success score. The completed
DOCX remains outside the repository; the repository retains its SHA-256 and anonymous aggregate.
