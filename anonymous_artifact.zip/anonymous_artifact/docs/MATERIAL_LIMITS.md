# Material scope and limits

## Included

- All retained rows needed to recompute the main target-choice, guided-native, original A/B tool-protocol and new-seed interleaved A/B/C results.
- Exact distributed model decision text, requested messages and inference settings, logical/native ID maps, admitted tool traces, action receipts, captured states and technical/format failure categories.
- Protocols, recovery records, aggregate reader summary, offline scorers and selected reference implementation sources.

## Excluded

- API keys, headers, provider response IDs, endpoints, request timing, billing records and transport databases.
- `.git`, caches, virtual environments, model weights, service databases, runtime overlays and unrelated historical drafts.
- Individual reader answers, free-text feedback, identities, consent records, private ethics files and hashes that could link to private returns.
- Upstream third-party runtime source. License notices are retained, but this artifact does not relicense or redistribute those repositories.
- The current manuscript source/PDF, bibliography, paper figures and generated TeX tables. They were used to freeze the result inventory but are not members of this package; `PAPER_RESULTS.md` provides the item-to-evidence map.

## Consequences for reproduction

- Main numerical results can be independently re-scored offline.
- Saved logical actions can be replayed against saved states and compared with captured final states.
- Fresh native-service execution is not performed by the offline scripts and requires external licensed runtimes.
- Fresh hosted-model execution requires credentials and current external services. Hosted weights are not pinned, so it is a new replication rather than an exact replay.
- Reader aggregates can be inspected but not independently rebuilt from private forms.

The omissions do not change entity IDs, task states, gold targets, action mappings, assigned denominators or scored outcomes.
