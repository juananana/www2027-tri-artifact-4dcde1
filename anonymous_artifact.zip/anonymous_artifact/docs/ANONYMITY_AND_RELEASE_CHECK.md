# Anonymity and release check

This check applies to the files in this package, not to the private source repository.

## Passed checks

- The manuscript source, manuscript PDF, bibliography, paper figures and generated TeX tables are not included in this artifact.
- Text scanning found no author-home paths, repository remotes, credential assignments, bearer tokens, private keys or OpenAI-style keys.
- A comparison against the local Git author name and email found no matches outside third-party license notices.
- No `.git` directory, cache, virtual environment, model weight, notebook, service database, `.DS_Store` or compiled Python file is included.
- ZIP member checks exclude `__MACOSX`, `.DS_Store` and AppleDouble `._*` entries.
- Individual reader answers, free text, identities, consent/ethics records and private-return hashes are excluded.
- Provider response IDs, HTTP headers, endpoints, timing records and transport databases are excluded from normalized results.
- Third-party notices are retained under `docs/third_party/`; the package does not assign a new license to upstream materials.

## Deliberately retained synthetic identifiers

The benchmark states contain `example.com` and synthetic benchmark `gmail.com` addresses. They are task entities or action arguments, not contributor contact details. Removing them would change the states and actions used by the scorers, so they are retained. Third-party copyright holders are retained for attribution.

## Release decision

The package is suitable for anonymous review on the checks above. Hosting status is intentionally not embedded in the archive. Before citing a review URL, upload the final ZIP rather than the working directory, verify the host does not reveal uploader identity, record the public checksum, and test anonymous download in a logged-out session.
