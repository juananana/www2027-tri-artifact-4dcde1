# Recovery decision record — 2026-10-26

## Verified baseline

- Original A/B/C run: 137/1680 assignments attempted; 589 formal/qualification responses; 3 retained `ConnectError` failures.
- All three failures were `[SSL: UNEXPECTED_EOF_WHILE_READING]`, with zero response events and no HTTP status.
- The failures ended at 11:49:46–47 Asia/Shanghai, one in each of three workers in the same second.
- DNS and certificate behavior are not persistently broken: the probe completed 20/20 unauthenticated HEAD requests with 1, 3, and 10 concurrent clients, each returning HTTP 400 after TLS. `curl`, `httpx`, and direct Python TLS all passed at probe time.
- The frozen inputs and 21 source hashes in `RUN_FREEZE.json` are unchanged. The independent audit still reports the original formal phase as incomplete (137 audited, 1543 missing).

## Inference and uncertainty

The evidence is consistent with a transient connection-path event amplified by three simultaneous fresh connections. It does not establish whether the proxied path, upstream service, or another transient network component caused the EOF. There is no evidence for a semantic/model failure or a certificate-verification problem.

## Recommended recovery

Create a separate prospective continuation record. Permanently retain the three failed assignments as unavailable; never resend them. Continue only unstarted assignments under the original randomized inventory and scoring, with two workers maximum, one request in flight per worker, a fresh client per request, and the original three-consecutive/five-in-fifty stop limits. Stop again on any certificate, contract, native-state, or budget failure. Keep a separate ledger and report the stopped and continued segments separately.

This is the smallest transport change that addresses the observed same-second concurrency pattern while preserving the scientific comparison. A successful continuation would demonstrate recoverability under the amended schedule, not identify the original root cause.

## Decision required before paid calls

The recovery continuation can approach the previously authorized CNY550 reference cap and changes the execution schedule after a frozen stop. The zero-call gate has passed, but a user decision is still required on whether to authorize this amended continuation before any new paid request. No paid request has been made from this recovery directory.
