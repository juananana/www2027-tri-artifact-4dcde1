# New-seed receipt and protocol replication — prospective protocol

Authorized by the human user in this chat on 2026-10-26, hard reference-cost cap CNY550. One hosted Qwen3.5-397B-A17B configuration only. Raw invoice unknown. No new models or instruction factorial. Current manuscript stays usable and can be edited from existing evidence while this study runs, per the user's explicit instruction.

## Claims and alternatives

1. On independently generated seed instances from the same seven previously reviewed families, determine whether paired action success and repeated target identities recur under the clarified receipt. This is replication within authored families, not unseen-family generalization.
2. Randomly interleave A/B to reduce sequential hosted-run confounding. A and B change only a constant returned recording note, preserving four-turn system/tool instructions and task inputs.
3. Compare B with C, which keeps the clarified note but permits up to eight calls and no fixed tool order. C permits recording after refresh and repeated reads/recordings. Its system describes these permissions. This tests a protocol bundle, not only one extra call or receipt causality in isolation.

## Frozen inputs and assignment

112 changed worlds,16 per family;28 related unchanged controls on four bases per family. Same seven selector/action families and short/explicit templates as the preceding study, with new random seed, fresh IDs, values and order. Candidate counts3/4/5/7, two update types, two repeats. Count-based templates necessarily repeat ranking structures; no claim of semantic independence from family templates.140 update variants x2 instruction forms x2 timing requirements x3 protocols=1680 formal sessions (560 per arm).

Within every world/update block, the12 sessions are randomly ordered independently of outcomes. Blocks are independently shuffled. Three isolated worker processes claim successive assignments from one shared queue. All A/B/C arms are distributed across the same runtime/time windows; time and backend identifiers are retained. Primary analyses retain every assignment.

Pilot: two disjoint development worlds, both applications, both forms and timing modes, all arms=24 sessions, excluded from scientific endpoints. No semantic pilot success threshold. Freeze precedes paid entry. Worlds, templates, order, endpoint, runtime, scorers and stopping rules are hash-pinned.

## Protocols

A: exact original four ordered calls (list, initial record, synchronize, action), terse recording receipt. B: identical, plus the unchanged previously tested pending-action sentence. C: clarified recording note, at most8 calls. C admits list and record before or after refresh; synchronize at most once; action must follow refresh and terminates. Malformed or invalid calls terminate; an action before refresh or repeated synchronization is a protocol rejection. No gold is supplied. No recorded ID is enforced. These preconditions are native/task constraints rather than a required four-step sequence.

All arms share task gold, native services, candidate observations and the selector/action definitions. Initial display behavior matches the original harness; post-refresh earlier-target position is counterbalanced. C may omit an initial record; such a trajectory can pass the entity-action endpoint but lacks the observable initial record required by the original strict endpoint. Strict is reported separately and never used to relabel a correct action as a wrong write.

## Readouts and analysis

Primary: both correct entity actions per changed world (112 per arm/form), with correct/wrong/no-action per timing condition. Native action success requires an accepted action on gold after refresh and exact expected captured fields. Report strict pairs using the original requirement: a correct first pre-refresh Preserve choice or Reevaluate deferral, refresh, correct action/state, no error. Preserve initial record is immutable for scoring; later recordings never overwrite its audit evidence. Report joint earlier-twice, updated-twice, reversed, other complete and missing-action outcomes. Controls remain separate (28).

Predeclared paired contrasts: B-A for explicit Reevaluate correct actions and explicit both-action pairs; C-B for short and explicit Reevaluate correct actions and both-action pairs. Also report all other condition counts, family counts, strict outcomes, initial errors, replacement after correct binding, tool rejections and technical failures.10000 family-then-world bootstrap draws, fixed seed2601026, shared resampled indices for every arm. Intervals describe seven authored families; no multiplicity-adjusted confirmatory mechanism claim. Do not require replication to meet a post-hoc70% threshold. Greater completion with extra wrong writes narrows the conclusion. A non-replicating B result or persistent C failure is retained and weakens the original interpretation.

## Transport, budget and interruption

Endpoint: existing authorized DashScope compatible chat endpoint; Qwen non-thinking, temperature0,top-p1,4096 completion cap; streaming,120s timeout, no automatic retry. Input bytes<=16000; reserve24000 input tokens per request. Rate reference checked2026-10-26: CNY1.2/7.2 per million input/output tokens. Max9090 qualification+formal requests, upper reference529.867008 CNY, enforced below550. Every attempted call is reserved before sending, persisted raw/events/usage/errors without credentials. Actual invoice unknown.

No request or partial session is retried. Interrupted tasks with retained directories require audit and count as unavailable if incomplete; never silently requeued. Isolated network ConnectError/ConnectTimeout/ReadTimeout retains the assignment and pauses15s before untouched work. Stop all workers at3 consecutive connection failures or5 failures in50 chronological requests; stop immediately on certificate, provider/contract, native consistency, budget or unclassified failures. Semantic errors and parse/truncation failures remain outcomes and do not trigger repair/tuning.

## Time and technical GO/NO-GO

Shanghai: no full batch starts at/after16:00. All paid calls stop at16:30; scientific manuscript freezes at18:00. Health+24-session pilot precede scaling. GO only if raw/state/receipt checks pass, frozen inputs remain unchanged, conservative total cost fits, and twice the observed request/session throughput with three workers forecasts remaining formal execution before16:30 plus90 minutes for independent audit/manuscript integration before18:00. Forecast uses kernel time, not AppWorld-frozen Python time. No semantic outcomes enter GO. If any gate fails, retain logs, record NO-GO, stop paid work and finish the stable zero-API revision. Partial results never enter the manuscript as complete evidence.
