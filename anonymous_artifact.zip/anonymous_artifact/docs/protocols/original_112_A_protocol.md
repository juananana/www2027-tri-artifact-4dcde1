# Prospective native instruction and action-completion replication

Status: preparation only; no paid authorization above the standing CNY20 envelope. This protocol addresses the user's 2026-10-25 request for adequate new experimental evidence. Historical runs, evidence, and manuscript results remain unchanged during qualification.

## Question and interpretation

Do the short/explicit instruction differences in earlier-target wrong writes and later-target action completion recur in new worlds and a second configuration? Report both outcomes together. The replication tests complete instruction versions, including their emphasis, and the existing four-step interface. It does not isolate a single temporal phrase or establish a universal remedy.

Strengthening evidence: the world-paired differences recur across new profiles and both configurations. Narrowing evidence: they occur in only one configuration, transition, position, or family. Contrary evidence: short instructions perform as well, or explicit instructions fail to preserve the earlier target. All are publishable outcomes. No outcome is a reason to rewrite a prompt or retry a semantic decision.

## Fixed population and conditions

112 new base worlds: seven previously reviewed unambiguous selector families, 16 per family. Exclude Todoist priority because its scale was already found ambiguous, before generating or observing new responses. Use Todoist latest due, first title, shortest duration; Simple Note last title, shortest content, longest content, most tags. Retain each original family action and both original short/explicit templates verbatim.

Each family crosses two update types (competitor update, restored eligibility), four candidate counts (3/4/5/7), and two independently seeded value sets/positions. Assign earlier-target first/last equally across worlds and keep position fixed within every matched comparison. Unlike the historical experiment, positions are counterbalanced across worlds rather than repeated within each world. Dates, title values, lengths, tag counts, rank gaps, distractors, and ordering vary, not only IDs. This covers existing families; it does not establish unseen-family or natural-language generalization. New instances do not receive new independent human judgments.

Add 28 related unchanged controls, four per family, retaining the same base state. They do not add independent worlds to the 112 primary bases. The development inventory is disjoint: 14 bases, with 21 variants, for model-free oracle and technical qualification only. Development evidence is never pooled with the primary panel.

Two hosted configurations: Qwen3.5-397B-A17B and GLM-5.2 through the documented Alibaba endpoint, non-thinking, requested temperature 0/top-p 1, completion cap 4,096, strict JSON parsing, no semantic retries. Keep the original four-step system prompt and tool interface unchanged: list_entities, record_choice, synchronize, perform_action. A correct target proposed to record_choice at the last step is recorded as a correct proposal and no action. Do not silently permit an extra turn to repair it.

2 configurations x 140 update variants x 2 instruction versions x 2 timing requirements = 1,120 primary sessions. Add 32 independent pilot sessions and four synthetic health calls: at most 4,612 requests overall. Each configuration gets the same worlds. The world, not the call, remains the analysis unit. Neither configurations nor related controls inflate the independent world count.

## Qualification and stopping

1. Freeze generated inputs, source dependencies, endpoints, request counts, pricing, and metrics before any paid call. Validate selectors, surviving action-valid targets, matched non-instruction fields, semantic-profile diversity, and overlap exclusion offline.
2. Run representative native oracles in isolated storage for both applications, both transitions, Preserve/Reevaluate, unchanged controls, and wrong-target checks. Verify persistent ID mapping, receipts, snapshots, interruption-safe evidence persistence, and no writes to source repositories. Scale model-free verification only after this representative test passes.
3. Implement and test the execution runner, accounting, interruption handling, independent raw reconstruction, and report generation before requesting paid entry. Preserve a final source/input manifest. The initial preparation manifest alone is not execution authorization or a completed runtime qualification.
4. After explicit budget authorization, run two synthetic transport checks per configuration, then a separate 16-session native pilot per configuration (two development worlds, both instruction versions, both modes, two positions). Its maximum 128 behavioral requests are included in the full budget. Pilot semantics never determine continuation; persistence, scoring agreement, latency, input/cost limits, and infrastructure health do. No prompt tuning.
5. Stop on any transport, native-runtime, evidence-persistence, or budget-envelope failure. Preserve all attempts; do not retry the request or launch the remainder. Any justified repair needs a recorded amendment and a new technical pilot. After two evidence-based approaches to the same fault, stop and explain the choices to the user.
6. Keep assigned primary rows and distinct attempted/completed/missing counts. An interrupted study is partial evidence and cannot be described as a completed replication. Deadline for primary execution: 2026-10-26 16:00 Asia/Shanghai, leaving time to audit and build before the earlier official submission cutoff. Stop earlier if reporting cannot be completed reliably.

## Endpoints and analysis

For each timing mode and instruction version, report correct native actions, wrong-entity writes, no action, initial decision correctness, correct final proposals, and captured final-state correctness. The three action outcomes partition assigned executions. Identify replacement only after correct observable initial selection and completed refresh; preserve all other failures separately.

Primary comparisons on the 112 changed worlds: paired difference in Preserve wrong-write incidence; paired difference in Reevaluate correct-action completion. Report complete P/R action-pair success as the joint utility endpoint. Use family-stratified world bootstrap and whole-family/world sensitivity (10,000 draws, seed 20261025); report all seven family outcomes and leave-one-family-out ranges. Treat secondary tests and subgroup results as descriptive. Report point differences and intervals rather than selecting a favorable p-value. Keep the historical 16-world panel separate.

Report unchanged controls, position and candidate-size partitions as secondary checks; do not claim randomized causal size effects. Make the input settings and interface differences from the 504-world prescribed-dispatch panel explicit. Do not treat zero wrong writes as task success when actions never complete.

## Budget and release

Published reference rates checked 2026-10-25: Qwen input/output CNY1.2/7.2 per million tokens; GLM CNY8/28, uncached. Sources: https://help.aliyun.com/zh/model-studio/qwen3-5-397b-a17b and https://help.aliyun.com/zh/model-studio/glm-5-2 . Actual billing is unknown. The full cost file includes primary, pilot, and health calls. The proposed CNY850 hard cap reserves the full 24,000 input-token / 4,096 completion-token envelope for each request; it is a conservative reference ceiling, not an expected invoice. Do not split a large intended operation into sub-CNY20 purchases to avoid approval. No paid requests before the full reviewed budget is authorized.

Retain immutable protocol/configuration/input manifests, all request and raw response streams, failure logs, native receipts and snapshots, a complete assigned-case ledger, executable independent reconstruction, JSON/CSV/Markdown reports, usage-based reference accounting, and the final integrity audit. Private credentials and human returns stay excluded. Complete experiments and audits, then freeze their narrative role before editing the active manuscript.
