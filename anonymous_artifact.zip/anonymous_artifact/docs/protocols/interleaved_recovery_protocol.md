# 2026-10-26 transport recovery and prospective continuation

This directory is a derived recovery record. The stopped A/B/C study and all
its frozen inputs remain unchanged under `../confirmatory_protocol_20261026/`.

## Observed fault

The original run recorded three `httpx.ConnectError` failures with
`SSL UNEXPECTED_EOF_WHILE_READING` at 11:49:46--47 Asia/Shanghai. Each had zero
stream events and no HTTP response. They occurred in three workers in the same
second after 589 successful qualification/formal responses. Root cause is
unknown.

## Recovery gate

`transport_probe.py` performs only DNS, TLS, and unauthenticated HEAD checks;
it sends zero model calls and uses no API credential. A recovery run may start
only if the probe passes for 1, 3, and 10 concurrent checks, the endpoint and
model configuration are revalidated, and this protocol is accepted before any
new paid request.

## Proposed continuation

The three failed assignments are permanently unavailable and are never
resent. The 1,543 unstarted assignments may be continued as a prospective
administrative amendment, with the original randomized inventory and scoring
unchanged. The amendment uses at most two model workers, one request in flight
per worker, a 15-second pause after any connection failure, and a fresh
per-request client with explicit 120-second total/15-second connect bounds.
It retains every request, response, failure, usage record, and assignment.
Any three consecutive connection failures, five in 50 requests, certificate
failure, contract/native inconsistency, or budget breach stops the amendment
again. Failed calls are unavailable and are never retried.

This amendment addresses the observed same-second concurrency pattern, but a
successful continuation would show only that the run was recoverable under a
different transport schedule; it would not identify the original root cause.
It also does not turn the first 137 assignments into a balanced efficacy
result. Any report must distinguish the original stopped segment from the
prospective continuation and retain the full assigned denominator.

## Scope of the two requested experiments

The A/B/C randomized comparison already uses one Qwen3.5-397B-A17B
configuration and executes target choice plus native action in the same session.
Thus it supplies the requested same-model choice-to-action link if completed;
no second model or 2x2 instruction factorial is added. C remains a protocol
bundle (flexible order, up to eight calls, and post-refresh recording), not an
isolated fifth-call causal test.

## Acceptance checks

1. Probe output exists and reports zero model calls.
2. Frozen stopped-study files hash unchanged.
3. Any continuation has a separate ledger and audit, with no duplicate request
   prefixes and no manuscript result unless the complete assigned comparison is
   independently recomputed before the scientific freeze.
