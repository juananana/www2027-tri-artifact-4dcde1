# Anonymous WWW 2027 TRI artifact

This package supports anonymous review of *Same Refresh, Opposite Targets: Evaluating Temporal Referent Integrity in Tool-Using Agents*. It explains the evaluation construction and recomputes the paper's principal results from retained model outputs, tool traces, receipts, ID maps and state snapshots without calling a model, API or native service.

The package is an offline verification artifact, not a claim of full environment replay. It does not contain credentials, model weights, service databases, provider envelopes, private reader forms or repository history. Failed, malformed and unavailable sessions remain in their assigned denominators.

## Quick start

Python 3.10 or later is sufficient for all count and state checks:

```bash
python3 -B src/verify_artifact.py .
```

The command verifies the manifest, reparses 6,000 target-selection responses, reconstructs all 3,240 guided-native cases, checks both 1,120-session original A/B runs, and reconstructs all 1,680 new-seed interleaved A/B/C sessions. It writes `results/OFFLINE_VERIFICATION.json` and prints `status: PASS` only when the retained rows reproduce the checked paper results.

The current interleaved confidence intervals use NumPy's deterministic generator. To reproduce them exactly:

```bash
python3 -m pip install -r requirements.txt
python3 -B src/recompute_interleaved_statistics.py .
```

Or run both steps with:

```bash
python3 -B scripts/recompute_all.py
```

Neither command opens a network connection. `requirements.txt` is needed only for the fixed-seed bootstrap; the main counts and state checks use the Python standard library.

## Evaluation panels

The panels must not be pooled or treated as repeated measurements from one protocol.

| Panel | Population and configuration | What is checked offline |
| --- | --- | --- |
| Target choice | 300 changed worlds per configuration; main Qwen model is Qwen3.5-27B (`Qwen27B`) | Raw JSON decision, selected ID, gold ID, paired target identity and related unchanged control |
| Guided native execution | 504 changed worlds per configuration; Qwen3.5-397B-A17B (`Qwen397B`) and GLM-5.2 | Initial binding/deferral, refreshed ID mapping, final action target, receipt, persistent state, paired action and strict success |
| Original tool protocol | 112 changed worlds plus 28 related unchanged controls; A is the terse receipt, B the clarified receipt | Four-call tool order, raw tool proposals, admitted calls, failures, action target, state change and strict trajectory evidence |
| New-seed interleaved comparison | 112 new-seed changed worlds plus 28 related unchanged controls; Qwen397B; arms A/B/C | Randomized block assignment, all 1,680 sessions, 32 retained connection failures, action/strict pairs, joint identities and family/world intervals |

`short` and `explicit` are distinct tested instruction versions. A/B/C are protocol arms. `target correctness`, `paired action success` and `strict paired action success` are different readouts; definitions and denominators are in `PAPER_RESULTS.md`.

## Contents

- `PAPER_RESULTS.md`: paper figure/table/result to data and scorer map, with verification status.
- `data/`: authored worlds, states, updates, instructions and gold targets.
- `results/`: every distributed per-session output and score record, including format and connection failures, plus regenerated verification reports.
- `src/verify_artifact.py`: standard-library offline scorer and state verifier.
- `src/recompute_interleaved_statistics.py`: fixed-seed NumPy recomputation of the current Table 2/Figure 5 analysis and intervals.
- `src/reference/`: retained author-side generator, controller, audit and analysis sources. These files document the original implementation; they are not a standalone hosted-service runner.
- `configs/`: model/protocol settings and environment locks.
- `scripts/`: one-command offline entry point.
- `docs/`: protocol records, human-evaluation workflow, material limits, anonymity checks and third-party notices.
- `PROVENANCE.json` and `MANIFEST.sha256`: source and release hashes.

The manuscript source, manuscript PDF, bibliography, paper figures and generated TeX tables are deliberately not included. Paper item labels in `PAPER_RESULTS.md` refer to the current submission manuscript used to freeze the result inventory; they are navigation labels, not paths to bundled paper files.

## Reproduction levels

1. **Offline re-scoring — provided and verified.** Reparse saved outputs, recompute selectors and gold targets, reconstruct admitted tool calls, map native IDs to logical entities, verify state mutations, and recompute paper counts.
2. **Saved-state execution reconstruction — provided and verified.** Reapply the logical action to the saved pre-action state and compare it with the captured final state. This is not a fresh native-service execution.
3. **Fresh native replay — not bundled as a one-command reproduction.** It requires the pinned AppWorld/OpenApps service stack and local runtime state. Reference implementation files and version records are included, but this release does not redistribute service databases.
4. **Fresh hosted-model run — optional and externally dependent.** It requires provider credentials and current hosted endpoints. Hosted weights are not pinned, so a new run cannot be expected to reproduce the retained outputs exactly. See `docs/OPTIONAL_MODEL_RERUN.md`.

## Human evaluation and restricted material

The package contains the public aggregate reader summary and evaluation workflow. Individual answers, free-text feedback, identities, consent records, ethics records and hashes of private returns remain private and cannot be independently re-scored from this artifact. This limits reproduction of the reader-study claim to checking the released aggregate and protocol.

## Third-party material

The worlds are author adaptations informed by public tool schemas and state semantics; they are not official benchmark results. No upstream runtime or model weights are redistributed. Relevant upstream license notices are retained under `docs/third_party/`; see `docs/THIRD_PARTY.md`.

## Current status

This package was prepared and validated for anonymous review. Hosting status and the review URL are maintained in the submission record rather than embedded in the archive.
